<?php
/**
 * Finalidade: abrir o HTML das telas públicas (landing, entrada, cadastro, confirmação e erros).
 * Variáveis opcionais: $tituloPagina, $descricaoPagina, $classeCorpo. As telas públicas são sempre escuras.
 */
$tituloPagina = $tituloPagina ?? 'Rec Wave';
$descricaoPagina = $descricaoPagina ?? 'Comunicação acústica subaquática: envie mensagens pela água e acompanhe cada etapa até a entrega.';
$classeCorpo = $classeCorpo ?? '';
?>
<!doctype html>
<html lang="pt-BR" data-theme="dark">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="color-scheme" content="dark">
	<meta name="theme-color" content="#02100c">
	<meta name="description" content="<?= escapar($descricaoPagina) ?>">
	<title><?= escapar($tituloPagina) ?></title>
	<link rel="icon" type="image/svg+xml" href="<?= rw_asset('img/favicon.svg') ?>">
	<link rel="preload" href="<?= rw_asset('fonts/bricolage-grotesque-latin-wght-normal.woff2') ?>" as="font" type="font/woff2" crossorigin>
	<link rel="stylesheet" href="<?= rw_asset('css/app.css') ?>">
	<script>document.documentElement.classList.add('js')</script>
</head>
<body class="<?= escapar($classeCorpo) ?>">
<a class="skip-link" href="#conteudo">Ir para o conteúdo</a>
