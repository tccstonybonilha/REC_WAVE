<?php /** Finalidade: fechar o HTML das telas públicas e carregar o JavaScript opcional. */ ?>
<script src="<?= rw_asset('js/app.js') ?>" defer></script>
</body>
</html>
