<?php
/**
 * Finalidade: componentes visuais reutilizáveis (ícones, logo, ondas, trilha de estado da mensagem,
 * etapas do cadastro e sinal pontilhado das páginas de erro). Só gera HTML/SVG; não acessa o banco.
 */

/** URL de um arquivo em assets/, com a data de modificação para o navegador atualizar o cache. */
function rw_asset(string $path): string
{
	$path = ltrim($path, '/');
	$file = __DIR__ . '/../assets/' . $path;
	return Response::url('assets/' . $path) . (is_file($file) ? '?v=' . filemtime($file) : '');
}

/** Ícones de traço (24x24). */
function rw_icon(string $name, int $size = 18, string $class = ''): string
{
	static $paths = [
		'eye' => '<path d="M2.06 12.35a1 1 0 0 1 0-.7 10.75 10.75 0 0 1 19.88 0 1 1 0 0 1 0 .7 10.75 10.75 0 0 1-19.88 0"/><circle cx="12" cy="12" r="3"/>',
		'eye-off' => '<path d="M10.73 5.08a10.74 10.74 0 0 1 11.21 6.57 1 1 0 0 1 0 .7 10.75 10.75 0 0 1-1.44 2.49"/><path d="M14.08 14.16a3 3 0 0 1-4.24-4.24"/><path d="M17.48 17.5a10.75 10.75 0 0 1-15.42-5.15 1 1 0 0 1 0-.7 10.75 10.75 0 0 1 4.45-5.14"/><path d="m2 2 20 20"/>',
		'check' => '<path d="M20 6 9 17l-5-5"/>',
		'x' => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
		'alert' => '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
		'lock' => '<rect width="18" height="11" x="3" y="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
		'logout' => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
		'arrow-left' => '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
		'send' => '<path d="M14.54 21.69a.5.5 0 0 0 .94-.02l6.5-19a.5.5 0 0 0-.64-.64l-19 6.5a.5.5 0 0 0-.02.94l7.93 3.18a2 2 0 0 1 1.11 1.11z"/><path d="m21.85 2.15-10.94 10.94"/>',
		'inbox' => '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
		'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
		'key' => '<path d="m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4"/><path d="m21 2-9.6 9.6"/><circle cx="7.5" cy="15.5" r="5.5"/>',
		'sliders' => '<path d="M4 21v-7"/><path d="M4 10V3"/><path d="M12 21v-9"/><path d="M12 8V3"/><path d="M20 21v-5"/><path d="M20 12V3"/><path d="M2 14h4"/><path d="M10 8h4"/><path d="M18 16h4"/>',
		'grid' => '<rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/>',
		'radio' => '<path d="M4.9 19.1C1 15.2 1 8.8 4.9 4.9"/><path d="M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5"/><circle cx="12" cy="12" r="2"/><path d="M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5"/><path d="M19.1 4.9C23 8.8 23 15.2 19.1 19.1"/>',
		'mail' => '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
		'clock' => '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
	];
	return '<svg class="icon' . ($class !== '' ? ' ' . $class : '') . '" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . ($paths[$name] ?? '') . '</svg>';
}

/** Marca do Rec Wave: círculo com uma onda. */
function rw_logo_mark(int $size = 28): string
{
	return '<svg class="brand-mark" width="' . $size . '" height="' . $size . '" viewBox="0 0 28 28" fill="none" aria-hidden="true" focusable="false">'
		. '<circle cx="14" cy="14" r="12.5" stroke="currentColor" stroke-width="1.4"/>'
		. '<path d="M6.5 15.5c1.9-5.2 3.7-5.2 5.4-.6s3.6 4.4 5.2-.8c.9-2.8 2.4-3.3 4.4-2.4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
}

function rw_brand(string $href, string $class = ''): string
{
	return '<a class="brand' . ($class !== '' ? ' ' . $class : '') . '" href="' . escapar($href) . '">' . rw_logo_mark() . '<span>Rec Wave</span></a>';
}

/**
 * Caminho de uma onda composta por harmônicas [amplitude, ciclos por bloco, fase].
 * O bloco tem a metade da largura total; assim a onda se repete sem emenda e pode deslizar em laço.
 */
function rw_wave_path(float $width, float $base, array $harmonics, float $closeAt = 0.0, int $step = 30): string
{
	$tile = $width / 2;
	$pts = [];
	for ($x = 0.0; $x <= $width + 0.01; $x += $step) {
		$y = $base;
		foreach ($harmonics as [$amp, $cycles, $phase]) {
			$y += $amp * sin(2 * M_PI * $cycles * $x / $tile + $phase);
		}
		$pts[] = [$x, $y];
	}
	$f = static fn (float $n): string => rtrim(rtrim(number_format($n, 1, '.', ''), '0'), '.');
	$d = 'M' . $f($pts[0][0]) . ' ' . $f($pts[0][1]);
	$n = count($pts);
	for ($i = 1; $i < $n - 1; $i++) {
		$mx = ($pts[$i][0] + $pts[$i + 1][0]) / 2;
		$my = ($pts[$i][1] + $pts[$i + 1][1]) / 2;
		$d .= 'Q' . $f($pts[$i][0]) . ' ' . $f($pts[$i][1]) . ' ' . $f($mx) . ' ' . $f($my);
	}
	$d .= 'L' . $f($pts[$n - 1][0]) . ' ' . $f($pts[$n - 1][1]);
	if ($closeAt > 0) $d .= 'L' . $f($width) . ' ' . $f($closeAt) . 'L0 ' . $f($closeAt) . 'Z';
	return $d;
}

/** Campo de ondas decorativo (três camadas que deslizam devagar; a animação vive no CSS). */
function rw_waves(string $class = ''): string
{
	static $layers = null;
	$w = 2880.0; $h = 420.0;
	$layers ??= [
		['a', 120, [[26, 1, 0.4], [10, 2, 1.7]], true],
		['b', 215, [[30, 1, 2.2], [12, 3, 0.3]], true],
		['c', 330, [[22, 2, 1.1], [9, 5, 2.4]], false],
	];
	$out = '<div class="waves' . ($class !== '' ? ' ' . $class : '') . '" aria-hidden="true"><svg viewBox="0 0 1440 ' . (int) $h . '" preserveAspectRatio="none" focusable="false">'
		. '<defs><linearGradient id="wave-fade" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="currentColor" stop-opacity=".16"/><stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient></defs>';
	foreach ($layers as [$id, $base, $harm, $fill]) {
		$out .= '<g class="wave wave-' . $id . '">';
		if ($fill) $out .= '<path class="wave-fill" fill="url(#wave-fade)" d="' . rw_wave_path($w, $base, $harm, $h) . '"/>';
		$out .= '<path class="wave-line" vector-effect="non-scaling-stroke" d="' . rw_wave_path($w, $base, $harm) . '"/></g>';
	}
	return $out . '</svg></div>';
}

/**
 * Trilha de estado de uma mensagem: quatro pontos (registrada, no gateway, no ar, entregue).
 * O trecho entre "no ar" e "entregue" é ondulado porque é o único que viaja pela água.
 */
function rw_track(string $status, string $label = ''): string
{
	$order = ['pending' => 0, 'sent_to_gateway' => 1, 'transmitted_acoustically' => 2, 'delivered' => 3];
	$tone = in_array($status, ['failed', 'expired'], true) ? $status : 'ok';
	$current = $order[$status] ?? -1;
	$xs = [7, 43, 79, 123];
	$svg = '<svg class="track track-' . $tone . '" viewBox="0 0 130 16" width="130" height="16"' . ($label !== '' ? ' role="img" aria-label="' . escapar($label) . '"' : ' aria-hidden="true"') . ' focusable="false">';
	for ($i = 0; $i < 3; $i++) {
		$x1 = $xs[$i] + 5; $x2 = $xs[$i + 1] - 5;
		$state = $tone === 'ok' && $i < $current ? 'done' : 'todo';
		$d = $i === 2 ? 'M' . $x1 . ' 8q4.25 -6 8.5 0t8.5 0t8.5 0t8.5 0' : 'M' . $x1 . ' 8H' . $x2;
		$svg .= '<path class="seg seg-' . $state . '" d="' . $d . '"/>';
	}
	foreach ($xs as $i => $x) {
		$state = $tone !== 'ok' ? 'off' : ($i < $current ? 'done' : ($i === $current ? 'current' : 'todo'));
		$svg .= '<circle class="node node-' . $state . '" cx="' . $x . '" cy="8" r="' . ($state === 'current' ? 4.5 : 3.5) . '"/>';
	}
	return $svg . '</svg>';
}

/** Etapas do cadastro: 0 = cadastro, 1 = confirmar e-mail, 2 = aprovação. */
function rw_stepper(int $current): string
{
	$out = '<ol class="steps" aria-label="Etapas do cadastro">';
	foreach (['Cadastro', 'Confirmar e-mail', 'Aprovação'] as $i => $label) {
		$class = $i < $current ? 'is-done' : ($i === $current ? 'is-current' : '');
		$out .= '<li class="' . $class . '"' . ($i === $current ? ' aria-current="step"' : '') . '>' . escapar($label) . '</li>';
	}
	return $out . '</ol>';
}

/** Linha pontilhada de sinal das páginas de erro; cada código conta a sua história. */
function rw_signal(string $kind): string
{
	$paths = [
		'flat' => 'M0 20H520',
		'lost' => 'M0 20q16.25 -16 32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0',
		'fade' => 'M0 20q16.25 -12 32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0t32.5 0',
		'jag' => 'M0 20l26 -12l26 24l26 -24l26 24l26 -24l26 24l26 -24l26 24l26 -24l26 24l26 -24l26 24l26 -24l26 24l26 -24l26 24l26 -12',
	];
	$d = $paths[$kind] ?? $paths['flat'];
	$end = $kind === 'lost' ? '<circle class="signal-end" cx="268" cy="20" r="4"/>' : '';
	return '<svg class="signal signal-' . escapar($kind) . '" viewBox="0 0 520 40" preserveAspectRatio="xMinYMid meet" aria-hidden="true" focusable="false">'
		. '<defs><linearGradient id="sig-fade" x1="0" x2="1" y1="0" y2="0"><stop offset="0" stop-color="currentColor"/><stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient></defs>'
		. '<path d="' . $d . '"' . ($kind === 'fade' ? ' stroke="url(#sig-fade)"' : '') . '/>' . $end . '</svg>';
}

/** Quantidade de solicitações aguardando decisão (para o selo do menu); 0 se o banco não responder. */
function rw_pending_requests(): int
{
	try {
		return (int) Database::connection()->query("SELECT COUNT(*) FROM users WHERE email_verified_at IS NOT NULL AND active=0 AND account_status='pending_approval'")->fetchColumn();
	} catch (Throwable) {
		return 0;
	}
}

/** Onda pequena e estática para enfeitar cartões (sem animação: movimento só quando responde a uma ação). */
function rw_card_wave(): string
{
	$w = 480.0; $h = 120.0;
	$main = rw_wave_path($w, 70, [[14, 1, 0.6], [5, 3, 1.2]], $h);
	$line = rw_wave_path($w, 70, [[14, 1, 0.6], [5, 3, 1.2]]);
	$soft = rw_wave_path($w, 52, [[10, 1, 3.4], [4, 3, 2.0]]);
	return '<svg class="card-wave" viewBox="0 0 480 120" preserveAspectRatio="none" aria-hidden="true" focusable="false">'
		. '<path class="cw-fill" d="' . $main . '"/><path class="cw-line cw-soft" d="' . $soft . '"/><path class="cw-line" d="' . $line . '"/></svg>';
}

/** Nível de acesso (viewer/operator/manager) no idioma da interface. */
function rw_level_label(?string $level): string
{
	return t(['viewer' => 'Visualização', 'operator' => 'Operação', 'manager' => 'Gestão'][$level ?? ''] ?? '—');
}
