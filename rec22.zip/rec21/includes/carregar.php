<?php
/**
 * Rec Wave/includes/carregar.php
 * Finalidade: iniciar sessão/segurança e incluir em um único lugar os componentes usados pelas páginas.
 */
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/../app/Support/Database.php';
require_once __DIR__ . '/../app/Support/RateLimiter.php';
require_once __DIR__ . '/../app/Services/MailService.php';
require_once __DIR__ . '/../app/Services/RegistrationService.php';
require_once __DIR__ . '/../app/Services/AuthenticationService.php';
require_once __DIR__ . '/../app/Middleware/AdminMiddleware.php';
require_once __DIR__ . '/../app/Controllers/AdminController.php';
require_once __DIR__ . '/../app/Controllers/ZoneController.php';
require_once __DIR__ . '/../app/Controllers/ManagementController.php';
