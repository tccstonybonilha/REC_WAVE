<?php
/** Finalidade: bloquear páginas que exigem um usuário autenticado. */
require_once __DIR__ . '/carregar.php';
AuthenticationService::requireAuth();
