<?php
/**
 * Rec Wave/includes/security.php
 * Finalidade: centralizar ambiente, sessão, CSRF, rate limit e headers de segurança de todas as páginas.
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../app/Support/Csrf.php';
require_once __DIR__ . '/../app/Support/Response.php';
require_once __DIR__ . '/../app/Support/Preferences.php';
require_once __DIR__ . '/../app/Support/I18n.php';
require_once __DIR__ . '/../app/Support/ErrorPage.php';
require_once __DIR__ . '/ui.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name(getenv('SESSION_NAME') ?: 'rec_wave_session');
    session_set_cookie_params([
        'httponly' => true,
        'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'samesite' => 'Lax',
    ]);
    session_start();
}
header_remove('X-Powered-By');
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');

/* Um único mecanismo de CSRF (classe Csrf, campo _csrf) para páginas e controladores. */
function campoCsrf(): string { return '<input type="hidden" name="_csrf" value="' . htmlspecialchars(Csrf::token(), ENT_QUOTES, 'UTF-8') . '">'; }
function verificarCsrf(): void { $token = $_POST['_csrf'] ?? null; Csrf::validate(is_string($token) ? $token : null); }
function escapar(?string $valor): string { return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8'); }
/* Tradução conforme o idioma escolhido (t) e o mesmo texto já escapado para HTML (et). */
function t(string $texto): string { return I18n::t($texto); }
function et(string $texto): string { return htmlspecialchars(I18n::t($texto), ENT_QUOTES, 'UTF-8'); }

/* Mostra ao usuário só mensagens de regra de negócio; erros técnicos (banco, SQL) vão para o log. */
function mensagemSegura(Throwable $e): string
{
	if ($e instanceof RuntimeException && !($e instanceof PDOException)) return $e->getMessage();
	error_log('Rec Wave: ' . get_class($e) . ': ' . $e->getMessage());
	return 'Não foi possível concluir a operação agora. Tente novamente em instantes.';
}

set_exception_handler(function (Throwable $e): void {
	error_log('Rec Wave: erro não tratado (' . get_class($e) . '): ' . $e->getMessage() . ' em ' . $e->getFile() . ':' . $e->getLine());
	$debug = filter_var(getenv('APP_DEBUG') ?: false, FILTER_VALIDATE_BOOLEAN);
	if (PHP_SAPI === 'cli' || headers_sent()) { echo 'Erro interno. Tente novamente em instantes.'; return; }
	ErrorPage::render(500, '', $debug ? get_class($e) . ': ' . $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')' : null);
});
