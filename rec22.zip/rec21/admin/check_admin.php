<?php
/** Finalidade: proteger todas as páginas dentro da pasta admin. */
require_once __DIR__ . '/../includes/security.php';
if (empty($_SESSION['user']['id']) || ($_SESSION['user']['role']??'')!=='admin') { header('Location: ../auth/login.php'); exit; }
