<?php
/** Finalidade: consultar os usuários cadastrados e seus estados. */
require_once __DIR__.'/check_admin.php';require_once __DIR__.'/../config/config.php';require_once __DIR__.'/../includes/carregar.php';AdminController::users();
