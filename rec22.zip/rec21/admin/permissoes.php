<?php
/** Finalidade: administrar a autorização dos usuários em cada zona. */
require_once __DIR__.'/check_admin.php';require_once __DIR__.'/../config/config.php';require_once __DIR__.'/../includes/carregar.php';ManagementController::permissions();
