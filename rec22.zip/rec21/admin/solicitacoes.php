<?php
/** Finalidade: listar e permitir decidir sobre solicitações de acesso. */
require_once __DIR__.'/check_admin.php';require_once __DIR__.'/../config/config.php';require_once __DIR__.'/../includes/carregar.php';AdminController::requests();
