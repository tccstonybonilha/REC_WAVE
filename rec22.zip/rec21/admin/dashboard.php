<?php
/** Finalidade: exibir o dashboard administrativo usando uma página PHP simples. */
require_once __DIR__.'/check_admin.php';require_once __DIR__.'/../config/config.php';require_once __DIR__.'/../includes/carregar.php';AdminController::dashboard();
