<?php
/**
 * Finalidade: definir os parâmetros SMTP sem armazenar credenciais no código.
 */

return [
    'app_env' => getenv('APP_ENV') ?: 'production',
    'mode' => getenv('MAIL_MODE') ?: 'smtp',
    'host' => getenv('MAIL_HOST') ?: 'smtp.gmail.com',
    'port' => (int) (getenv('MAIL_PORT') ?: 587),
    'username' => getenv('MAIL_USERNAME') ?: '',
    'password' => getenv('MAIL_PASSWORD') ?: '',
    'encryption' => getenv('MAIL_ENCRYPTION') ?: 'tls',
    'from_address' => getenv('MAIL_FROM_ADDRESS') ?: (getenv('MAIL_USERNAME') ?: ''),
    'from_name' => getenv('MAIL_FROM_NAME') ?: 'Rec Wave',
];
