<?php
/**
 * Rec Wave/config/config.php
 * Finalidade: carregar o .env (sem sobrescrever variáveis já definidas no servidor) e definir APP_URL.
 */
if (!function_exists('carregarConfiguracao')) {
    function carregarConfiguracao(string $arquivo): void {
        if (!is_readable($arquivo)) return;
        foreach (file($arquivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $linha) {
            $linha = trim($linha);
            if ($linha === '' || str_starts_with($linha, '#') || !str_contains($linha, '=')) continue;
            [$chave, $valor] = explode('=', $linha, 2);
            $valor = trim($valor);
            /* Remove aspas apenas quando abrem e fecham o valor inteiro; senhas que começam ou terminam com aspa ficam intactas. */
            if (strlen($valor) >= 2 && ($valor[0] === '"' || $valor[0] === "'") && $valor[0] === substr($valor, -1)) {
                $valor = substr($valor, 1, -1);
            }
            if (getenv(trim($chave)) === false) putenv(trim($chave) . '=' . $valor);
        }
    }
}
carregarConfiguracao(__DIR__ . '/../.env');
if (!defined('APP_URL')) define('APP_URL', rtrim(getenv('APP_URL') ?: 'http://localhost:8000', '/'));

/* Datas sempre em UTC (PHP e MySQL) e exibição de erros controlada por APP_DEBUG. */
date_default_timezone_set('UTC');
$recWaveDebug = filter_var(getenv('APP_DEBUG') ?: false, FILTER_VALIDATE_BOOLEAN);
ini_set('display_errors', (PHP_SAPI === 'cli' || $recWaveDebug) ? '1' : '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);
