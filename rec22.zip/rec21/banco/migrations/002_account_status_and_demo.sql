-- Finalidade: distinguir estados de aprovação e identificar mensagens de demonstração.
ALTER TABLE users ADD COLUMN account_status ENUM('pending_email','pending_approval','approved','rejected','disabled') NOT NULL DEFAULT 'pending_email' AFTER role;
ALTER TABLE users ADD COLUMN approved_at DATETIME(3) NULL, ADD COLUMN approved_by BIGINT UNSIGNED NULL, ADD COLUMN rejection_reason VARCHAR(500) NULL;
ALTER TABLE messages ADD COLUMN is_demo TINYINT(1) NOT NULL DEFAULT 0 AFTER status;
