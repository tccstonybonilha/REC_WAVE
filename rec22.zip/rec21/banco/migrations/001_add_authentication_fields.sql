-- Finalidade: adicionar apenas os campos necessários à autenticação sem apagar dados existentes.
-- Execute somente após confirmar que os campos ainda não existem no banco.
ALTER TABLE users ADD COLUMN email_verified_at DATETIME(3) NULL AFTER active;
ALTER TABLE users ADD COLUMN verification_code_hash VARCHAR(255) NULL AFTER email_verified_at;
ALTER TABLE users ADD COLUMN verification_expires_at DATETIME(3) NULL AFTER verification_code_hash;
ALTER TABLE users ADD COLUMN verification_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER verification_expires_at;
ALTER TABLE users ADD COLUMN verification_requested_at DATETIME(3) NULL AFTER verification_attempts;
ALTER TABLE users ADD COLUMN role ENUM('user','admin') NOT NULL DEFAULT 'user' AFTER active;
CREATE INDEX idx_users_email_verification ON users (email, email_verified_at);
