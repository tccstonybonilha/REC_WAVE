-- Finalidade: garantir que approved_by aponte para um usuário existente (quem aprovou).
-- Requer users.id do mesmo tipo da coluna (BIGINT UNSIGNED, como no esquema de referência).
-- Se o seu banco antigo usa INT em users.id, ajuste o tipo de approved_by antes de executar.
ALTER TABLE users
  ADD CONSTRAINT fk_users_approved_by FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL;
