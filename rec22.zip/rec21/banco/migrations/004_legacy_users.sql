-- Finalidade: liberar usuários criados ANTES do fluxo de confirmação de e-mail.
-- Depois da migration 002 eles ficam com account_status='pending_email' e e-mail "não confirmado",
-- e por isso não conseguem entrar nem virar administrador com banco/criar_admin.php.
-- Só atinge linhas sem nenhum rastro do novo fluxo (sem código e sem pedido de verificação).
-- Quem já estava ativo (active=1) vira "approved"; quem estava inativo vira "pending_approval"
-- e aparece em Solicitações para o administrador decidir.
UPDATE users
SET email_verified_at = COALESCE(created_at, NOW(3)),
    account_status = IF(active = 1, 'approved', 'pending_approval'),
    approved_at = IF(active = 1, COALESCE(approved_at, created_at, NOW(3)), approved_at)
WHERE email_verified_at IS NULL
  AND verification_code_hash IS NULL
  AND verification_requested_at IS NULL
  AND account_status = 'pending_email';
