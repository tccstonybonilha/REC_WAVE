-- Finalidade: adotar o fluxo de estados da mensagem: pending -> sent_to_gateway -> transmitted_acoustically -> delivered
-- (failed e expired continuam como estados finais). O antigo "sent" vira "sent_to_gateway".
ALTER TABLE messages MODIFY status ENUM('pending','sent','sent_to_gateway','transmitted_acoustically','delivered','failed','expired') NOT NULL DEFAULT 'pending';
UPDATE messages SET status = 'sent_to_gateway' WHERE status = 'sent';
ALTER TABLE messages MODIFY status ENUM('pending','sent_to_gateway','transmitted_acoustically','delivered','failed','expired') NOT NULL DEFAULT 'pending';
