-- Finalidade: tabela de controle de tentativas (login, cadastro e confirmação de e-mail).
-- A aplicação também cria esta tabela sozinha na primeira tentativa, se ela não existir.
CREATE TABLE IF NOT EXISTS rate_limits (
	id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	bucket CHAR(64) NOT NULL,
	created_at DATETIME(3) NOT NULL,
	INDEX idx_rate_limits_bucket (bucket, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
