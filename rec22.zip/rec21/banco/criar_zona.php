<?php
/**
 * Finalidade: cadastrar uma zona real, sem dados fictícios.
 * Uso: php banco/criar_zona.php "Nome da zona" ["Descrição opcional"]
 */
if (PHP_SAPI !== 'cli') exit('Execute pela linha de comando.');
require dirname(__DIR__) . '/bootstrap.php';
require dirname(__DIR__) . '/app/Support/Database.php';
$nome = trim($argv[1] ?? '');
$descricao = trim($argv[2] ?? '');
if ($nome === '' || mb_strlen($nome, 'UTF-8') > 120) exit("Informe o nome da zona (até 120 caracteres).\n");
if (mb_strlen($descricao, 'UTF-8') > 500) exit("A descrição pode ter no máximo 500 caracteres.\n");
$db = Database::connection();
$existe = $db->prepare('SELECT id FROM zones WHERE name=?');
$existe->execute([$nome]);
if ($existe->fetchColumn()) exit("Já existe uma zona com esse nome.\n");
$db->prepare('INSERT INTO zones(name,description,active,created_at,updated_at) VALUES(?,?,1,NOW(3),NOW(3))')->execute([$nome, $descricao === '' ? null : $descricao]);
echo "Zona criada: {$nome}\n";
