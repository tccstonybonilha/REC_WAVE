-- Finalidade: documentar o esquema de referência compatível com o diagrama fornecido.
-- Não executar em produção sobre um banco existente sem revisão e backup.
CREATE TABLE IF NOT EXISTS users (
	id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	name VARCHAR(120) NOT NULL,
	email VARCHAR(190) NOT NULL UNIQUE,
	password_hash VARCHAR(255) NOT NULL,
	active TINYINT(1) NOT NULL DEFAULT 0,
	role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
	account_status ENUM(
		'pending_email',
		'pending_approval',
		'approved',
		'rejected',
		'disabled'
	) NOT NULL DEFAULT 'pending_email',
	email_verified_at DATETIME(3) NULL,
	verification_code_hash VARCHAR(255) NULL,
	verification_expires_at DATETIME(3) NULL,
	verification_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
	verification_requested_at DATETIME(3) NULL,
	approved_at DATETIME(3) NULL,
	approved_by BIGINT UNSIGNED NULL,
	rejection_reason VARCHAR(500) NULL,
	created_at DATETIME(3) NOT NULL,
	updated_at DATETIME(3) NOT NULL,
	CONSTRAINT fk_users_approved_by FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS zones (
	id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	name VARCHAR(120) NOT NULL,
	description VARCHAR(500) NULL,
	active TINYINT(1) NOT NULL DEFAULT 1,
	gateway_uid VARCHAR(100) NULL,
	gateway_token_hash CHAR(64) NULL,
	gateway_name VARCHAR(120) NULL,
	firmware_version VARCHAR(40) NULL,
	last_seen_at DATETIME(3) NULL,
	wifi_rssi SMALLINT NULL,
	uptime_seconds BIGINT UNSIGNED NULL,
	created_at DATETIME(3) NOT NULL,
	updated_at DATETIME(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS zone_users (
	zone_id BIGINT UNSIGNED NOT NULL,
	user_id BIGINT UNSIGNED NOT NULL,
	access_level ENUM('viewer', 'operator', 'manager') NOT NULL DEFAULT 'viewer',
	created_at DATETIME(3) NOT NULL,
	PRIMARY KEY (zone_id, user_id),
	FOREIGN KEY (zone_id) REFERENCES zones(id),
	FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS messages (
	id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	zone_id BIGINT UNSIGNED NOT NULL,
	sender_user_id BIGINT UNSIGNED NOT NULL,
	content VARCHAR(255) NOT NULL,
	status ENUM('pending', 'sent_to_gateway', 'transmitted_acoustically', 'delivered', 'failed', 'expired') NOT NULL DEFAULT 'pending',
	is_demo TINYINT(1) NOT NULL DEFAULT 0, -- legado: o código não grava mais mensagens de demonstração
	protocol_version VARCHAR(20) NULL,
	created_at DATETIME(3) NOT NULL,
	expires_at DATETIME(3) NULL,
	sent_at DATETIME(3) NULL,
	delivered_at DATETIME(3) NULL,
	FOREIGN KEY (zone_id) REFERENCES zones(id),
	FOREIGN KEY (sender_user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Reservada para a etapa do gateway/ESP32 (tentativas de entrega por mensagem). Ainda não é usada pelo código.
CREATE TABLE IF NOT EXISTS message_deliveries (
	id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	message_id BIGINT UNSIGNED NOT NULL,
	zone_id BIGINT UNSIGNED NOT NULL,
	direction ENUM('outbound', 'inbound') NOT NULL,
	status ENUM('pending', 'sent', 'received', 'failed') NOT NULL DEFAULT 'pending',
	attempts INT NOT NULL DEFAULT 0,
	error_message VARCHAR(500) NULL,
	created_at DATETIME(3) NOT NULL,
	sent_at DATETIME(3) NULL,
	received_at DATETIME(3) NULL,
	FOREIGN KEY (message_id) REFERENCES messages(id),
	FOREIGN KEY (zone_id) REFERENCES zones(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rate_limits (
	id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	bucket CHAR(64) NOT NULL,
	created_at DATETIME(3) NOT NULL,
	INDEX idx_rate_limits_bucket (bucket, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
