<?php
/**
 * Finalidade: promover um usuário confirmado a administrador inicial sem senha fixa no código.
 * Uso: php banco/criar_admin.php email@dominio.com
 */
require dirname(__DIR__) . '/bootstrap.php';
require dirname(__DIR__) . '/app/Support/Database.php';
$email = strtolower(trim($argv[1] ?? getenv('INITIAL_ADMIN_EMAIL') ?: ''));
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) exit("Informe um e-mail válido.\n");
$stmt = Database::connection()->prepare("UPDATE users SET active=1, role='admin', account_status='approved', approved_at=COALESCE(approved_at,NOW(3)), updated_at=NOW(3) WHERE email=? AND email_verified_at IS NOT NULL");
$stmt->execute([$email]);
if ($stmt->rowCount() !== 1) exit("Usuário não encontrado ou e-mail ainda não confirmado.\n");
echo "Administrador inicial habilitado: {$email}\n";
