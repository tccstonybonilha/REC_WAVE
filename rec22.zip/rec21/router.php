<?php
/**
 * Finalidade: roteador do servidor embutido do PHP (php -S localhost:8000 router.php).
 * Mostra a página 404 do Rec Wave e bloqueia as pastas internas, como o .htaccess faz no Apache.
 */
$caminho = rawurldecode((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH));
$interno = '#^/(?:app|config|includes|banco|resources|tests|vendor|storage)(?:/|$)|/\.|^/(?:composer\.(?:json|lock)|README\.md|bootstrap\.php|router\.php)$#i';

if (preg_match($interno, $caminho)) {
	require __DIR__ . '/erros/403.php';
	return true;
}
$arquivo = realpath(__DIR__ . $caminho);
if ($caminho === '/' || ($arquivo !== false && str_starts_with($arquivo, __DIR__) && (is_file($arquivo) || is_file($arquivo . '/index.php')))) {
	return false; // o servidor entrega o arquivo ou o index.php da pasta
}
require __DIR__ . '/erros/404.php';
return true;
