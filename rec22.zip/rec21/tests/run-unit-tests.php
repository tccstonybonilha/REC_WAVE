<?php
/**
 * Finalidade: testar sem banco o leitor do .env, preferências, tradução, validações e regras de acesso.
 * Uso: php tests/run-unit-tests.php
 */
require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/Support/Response.php';
require_once __DIR__ . '/../app/Support/Preferences.php';
require_once __DIR__ . '/../app/Support/I18n.php';
require_once __DIR__ . '/../app/Services/RegistrationService.php';
require_once __DIR__ . '/../app/Controllers/ZoneController.php';
if (!function_exists('t')) { function t(string $texto): string { return I18n::t($texto); } }

function expect(bool $condition, string $message): void
{
    if (!$condition) throw new RuntimeException('FALHOU: ' . $message);
}

function expectThrows(callable $fn, string $fragment, string $message): void
{
    try { $fn(); } catch (Throwable $e) {
        expect(str_contains($e->getMessage(), $fragment), $message . ' (mensagem recebida: ' . $e->getMessage() . ')');
        return;
    }
    throw new RuntimeException('FALHOU: ' . $message . ' (nenhuma exceção)');
}

/* 1) Leitor do .env: aspas só saem quando envolvem o valor inteiro. */
$arquivo = tempnam(sys_get_temp_dir(), 'recwave-env');
file_put_contents($arquivo, implode("\r\n", [
    '# comentário',
    'RW_T1="com aspas"',
    "RW_T2='aspas simples'",
    'RW_T3="comeca-com-aspa',
    'RW_T4=termina-com-aspa"',
    'RW_T5=  com espacos  ',
    'RW_T6=a=b=c',
    'RW_T7=',
]));
carregarConfiguracao($arquivo);
unlink($arquivo);
expect(getenv('RW_T1') === 'com aspas', 'aspas duplas do par externo devem sair');
expect(getenv('RW_T2') === 'aspas simples', 'aspas simples do par externo devem sair');
expect(getenv('RW_T3') === '"comeca-com-aspa', 'senha que começa com aspa deve ficar intacta');
expect(getenv('RW_T4') === 'termina-com-aspa"', 'senha que termina com aspa deve ficar intacta');
expect(getenv('RW_T5') === 'com espacos', 'espaços das pontas saem');
expect(getenv('RW_T6') === 'a=b=c', 'só o primeiro = separa chave e valor');

/* 2) Preferências: só valores permitidos; sessão vale mais que cookie. */
$_SESSION = []; $_COOKIE = [];
expect(Preferences::get() === ['theme' => 'dark', 'language' => 'pt-BR'], 'padrão deve ser escuro e pt-BR');
$_COOKIE = ['rw_theme' => 'neon', 'rw_lang' => 'xx'];
expect(Preferences::get()['theme'] === 'dark' && Preferences::get()['language'] === 'pt-BR', 'cookie inválido volta ao padrão');
$_COOKIE = ['rw_theme' => 'light', 'rw_lang' => 'en'];
expect(Preferences::get() === ['theme' => 'light', 'language' => 'en'], 'cookie válido deve ser lido');
Preferences::save('dark', 'pt-BR');
expect(Preferences::get() === ['theme' => 'dark', 'language' => 'pt-BR'], 'sessão sobrepõe o cookie');
Preferences::save(['x'], null);
expect(Preferences::get() === ['theme' => 'dark', 'language' => 'pt-BR'], 'save com valores inválidos usa o padrão');

/* 3) Tradução e rótulos. */
$_SESSION = []; $_COOKIE = [];
expect(t('Sair') === 'Sair', 'em português o texto não muda');
Preferences::save('dark', 'en');
expect(t('Sair') === 'Sign out', 'em inglês o texto é traduzido');
expect(t('Texto sem tradução') === 'Texto sem tradução', 'o que não está no dicionário continua igual');
expect(Response::accountStatus('pending_approval') === 'Awaiting approval', 'rótulo de conta em inglês');
Preferences::save('dark', 'pt-BR');
expect(Response::accountStatus('pending_approval') === 'Aguardando aprovação', 'rótulo de conta em português');
expect(Response::messageStatus('sent_to_gateway') === 'Enviada ao gateway', 'rótulo de mensagem');
expect(Response::dt('2026-10-22 10:00:00.123') === '2026-10-22 10:00:00 UTC', 'data exibida em UTC');
expect(Response::dt(null) === '', 'data nula vira vazio');

/* 4) Validação do cadastro (acontece antes de qualquer acesso ao banco). */
expectThrows(fn() => RegistrationService::request('nao-e-email', 'Maria', 'senha-boa-123'), 'e-mail válido', 'e-mail inválido');
expectThrows(fn() => RegistrationService::request('a@example.test', 'M', 'senha-boa-123'), 'nome', 'nome curto');
expectThrows(fn() => RegistrationService::request('a@example.test', 'Maria', '1234567'), 'pelo menos 8', 'senha curta');
expectThrows(fn() => RegistrationService::request('a@example.test', 'Maria', str_repeat('x', 73)), 'máximo 72', 'senha longa');

/* 5) Regras de envio e de mensagem. */
expect(ZoneController::canSend('operator') && ZoneController::canSend('manager'), 'operator e manager enviam');
expect(!ZoneController::canSend('viewer') && !ZoneController::canSend(null), 'viewer e sem vínculo não enviam');
expect(ZoneController::validateMessage('   ') === 'Escreva uma mensagem.', 'mensagem vazia');
expect(ZoneController::validateMessage(str_repeat('ã', 255)) === null, '255 caracteres multibyte é válido');
expect(ZoneController::validateMessage(str_repeat('ã', 256)) !== null, '256 caracteres é inválido');

/* 6) Caminho base: APP_BASE_PATH resolve Alias e links simbólicos. */
putenv('APP_BASE_PATH=/rec21/');
expect(Response::basePath() === '/rec21', 'APP_BASE_PATH normalizado');
expect(Response::url('zonas/index.php') === '/rec21/zonas/index.php', 'URL com prefixo');

echo "OK: .env, preferências, tradução, rótulos, validação do cadastro, regras de envio e caminho base.\n";
