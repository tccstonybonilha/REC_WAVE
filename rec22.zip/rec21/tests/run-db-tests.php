<?php
/**
 * Finalidade: testar com MySQL o cadastro, a confirmação, o login, a aprovação, as permissões e o limite de tentativas.
 * ATENÇÃO: apaga e recria as tabelas do banco de testes. Só roda se TEST_DB_DATABASE contiver "test"
 * e for diferente de DB_DATABASE.
 * Uso: TEST_DB_DATABASE=rec_wave_test php tests/run-db-tests.php
 */
require_once __DIR__ . '/../bootstrap.php';

$testDb = getenv('TEST_DB_DATABASE') ?: '';
$mainDb = getenv('DB_DATABASE') ?: 'rec_wave';
if ($testDb === '' || stripos($testDb, 'test') === false || $testDb === $mainDb) {
    fwrite(STDERR, "Recusado: defina TEST_DB_DATABASE com um banco de testes (o nome precisa conter 'test' e ser diferente de DB_DATABASE).\n");
    exit(1);
}
putenv('DB_DATABASE=' . $testDb);
putenv('APP_ENV=local');
putenv('MAIL_MODE=log');

require_once __DIR__ . '/../app/Support/Response.php';
require_once __DIR__ . '/../app/Support/Preferences.php';
require_once __DIR__ . '/../app/Support/I18n.php';
require_once __DIR__ . '/../app/Support/Database.php';
require_once __DIR__ . '/../app/Support/RateLimiter.php';
require_once __DIR__ . '/../app/Services/MailService.php';
require_once __DIR__ . '/../app/Services/RegistrationService.php';
require_once __DIR__ . '/../app/Services/AuthenticationService.php';
require_once __DIR__ . '/../app/Controllers/AdminController.php';
require_once __DIR__ . '/../app/Controllers/ManagementController.php';
require_once __DIR__ . '/../app/Controllers/ZoneController.php';
if (!function_exists('t')) { function t(string $texto): string { return I18n::t($texto); } }

function expect(bool $condition, string $message): void
{
    if (!$condition) throw new RuntimeException('FALHOU: ' . $message);
}

function expectThrows(callable $fn, string $fragment, string $message, ?string $class = null): void
{
    try { $fn(); } catch (Throwable $e) {
        expect(str_contains($e->getMessage(), $fragment), $message . ' (mensagem recebida: ' . $e->getMessage() . ')');
        if ($class !== null) expect($e instanceof $class, $message . ' (classe esperada ' . $class . ', recebida ' . get_class($e) . ')');
        return;
    }
    throw new RuntimeException('FALHOU: ' . $message . ' (nenhuma exceção)');
}

$logPath = __DIR__ . '/../storage/logs/mail.log';
$hadLog = is_file($logPath);
$originalLog = $hadLog ? file_get_contents($logPath) : null;

function mailCount(string $logPath): int { return is_file($logPath) ? preg_match_all('/Seu código é: \d{6}/u', file_get_contents($logPath)) : 0; }
function latestCode(string $logPath): string
{
    preg_match_all('/Seu código é: (\d{6})/u', (string) @file_get_contents($logPath), $m);
    expect(!empty($m[1]), 'nenhum código encontrado em mail.log');
    return end($m[1]);
}
function scalar(PDO $db, string $sql, array $params = []): mixed { $s = $db->prepare($sql); $s->execute($params); return $s->fetchColumn(); }
function userId(PDO $db, string $email): int { return (int) scalar($db, 'SELECT id FROM users WHERE email=?', [$email]); }
function confirmUser(PDO $db, string $logPath, string $email, string $name, string $pass): void
{
    RegistrationService::request($email, $name, $pass);
    RegistrationService::verify($email, latestCode($logPath), $pass);
}

try {
    /* Recria o esquema do zero no banco de testes. */
    $db = Database::connection();
    $db->exec('SET FOREIGN_KEY_CHECKS=0');
    foreach (['message_deliveries', 'messages', 'zone_users', 'zones', 'users', 'rate_limits'] as $table) $db->exec("DROP TABLE IF EXISTS {$table}");
    $db->exec('SET FOREIGN_KEY_CHECKS=1');
    $sql = preg_replace('/--[^\n]*/', '', (string) file_get_contents(__DIR__ . '/../banco/banco_dados.sql'));
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $statement) $db->exec($statement);

    /* Administrador criado direto no banco (aprovação real passa pela tela). */
    $hash = password_hash('admin-senha-123', PASSWORD_DEFAULT);
    $db->prepare("INSERT INTO users (name,email,password_hash,active,role,account_status,email_verified_at,created_at,updated_at) VALUES ('Admin','admin@example.test',?,1,'admin','approved',NOW(3),NOW(3),NOW(3))")->execute([$hash]);
    $adminId = userId($db, 'admin@example.test');

    /* Cadastro, e-mail e confirmação. */
    $alice = 'alice@example.test'; $pass = 'senha-forte-123';
    expect(RegistrationService::request($alice, 'Alice', $pass) === true, 'cadastro novo deve enviar código');
    $code = latestCode($logPath);
    expectThrows(fn() => AuthenticationService::login($alice, $pass), 'Confirme seu e-mail', 'login antes de confirmar o e-mail');
    $mails = mailCount($logPath);
    expect(RegistrationService::request($alice, 'Alice', $pass) === false, 'novo pedido em menos de 60 s é ignorado');
    expect(mailCount($logPath) === $mails, 'o pedido ignorado não envia outro e-mail');
    expect(RegistrationService::request($adminEmail = 'admin@example.test', 'Outro', 'qualquer-senha-1') === false, 'e-mail já confirmado não revela nada e não envia');
    expectThrows(fn() => AuthenticationService::login($alice, 'errada'), 'inválidos', 'senha errada', InvalidCredentialsException::class);
    expectThrows(fn() => AuthenticationService::login('nao-existe@example.test', 'x'), 'inválidos', 'e-mail inexistente', InvalidCredentialsException::class);
    expectThrows(fn() => RegistrationService::verify($alice, '000000', $pass), 'Código inválido', 'código errado');
    expectThrows(fn() => RegistrationService::verify($alice, $code, 'outra-senha-123'), 'senha não confere', 'senha diferente da do cadastro');
    RegistrationService::verify($alice, $code, $pass);
    expect(scalar($db, 'SELECT account_status FROM users WHERE email=?', [$alice]) === 'pending_approval', 'confirmar o e-mail não ativa a conta');
    expectThrows(fn() => RegistrationService::verify($alice, $code, $pass), 'Código inválido', 'código só vale uma vez');

    /* Aprovação. */
    $aliceId = userId($db, $alice);
    try { AuthenticationService::login($alice, $pass); throw new RuntimeException('FALHOU: login antes da aprovação'); }
    catch (RuntimeException $e) { expect(str_contains($e->getMessage(), 'aguarda aprovação') && !($e instanceof InvalidCredentialsException), 'aguardando aprovação não é erro de credencial'); }
    $approved = AdminController::approveUser($aliceId, $adminId);
    expect($approved !== null && $approved['email'] === $alice, 'aprovar solicitação pendente');
    expect(AdminController::approveUser($aliceId, $adminId) === null, 'não aprova duas vezes');
    expect((int) scalar($db, 'SELECT approved_by FROM users WHERE id=?', [$aliceId]) === $adminId, 'approved_by gravado');
    expect(AdminController::approveUser($adminId, $adminId) === null, 'não "aprova" administrador');
    AuthenticationService::login($alice, $pass);
    expect(($_SESSION['user']['id'] ?? 0) == $aliceId, 'login após aprovação');
    expect(AuthenticationService::activeRole($aliceId) === 'user', 'papel lido do banco');
    $db->prepare("UPDATE users SET active=0, account_status='disabled' WHERE id=?")->execute([$aliceId]);
    expect(AuthenticationService::activeRole($aliceId) === null, 'conta desativada perde o acesso na hora');
    expect(AdminController::approveUser($aliceId, $adminId) === null, 'conta desativada não é reativada por aprovar');
    $db->prepare("UPDATE users SET active=1, account_status='approved' WHERE id=?")->execute([$aliceId]);

    /* Recusa. */
    $bob = 'bob@example.test';
    confirmUser($db, $logPath, $bob, 'Bob', $pass);
    $bobId = userId($db, $bob);
    expect(AdminController::rejectUser($adminId, 'x') === false, 'não recusa administrador');
    expect(AdminController::rejectUser($bobId, 'Motivo') === true, 'recusa solicitação pendente');
    expect(AdminController::rejectUser($bobId, 'Motivo') === false, 'não recusa duas vezes');
    expect(AdminController::rejectUser($aliceId, 'x') === false, 'não recusa conta já aprovada');

    /* Pré-sequestro: quem recadastra o e-mail alheio não consegue entregar a conta. */
    $carol = 'carol@example.test';
    RegistrationService::request($carol, 'Carol', 'senha-da-carol-1');
    $db->prepare("UPDATE users SET verification_requested_at = NOW(3) - INTERVAL 2 MINUTE WHERE email=?")->execute([$carol]);
    RegistrationService::request($carol, 'Atacante', 'senha-do-atacante-1');
    $newCode = latestCode($logPath);
    expectThrows(fn() => RegistrationService::verify($carol, $newCode, 'senha-da-carol-1'), 'senha não confere', 'o dono do e-mail não confirma com a senha dele');

    /* Falha no envio de e-mail não deixa conta gravada. */
    putenv('MAIL_MODE=smtp'); putenv('MAIL_USERNAME='); putenv('MAIL_PASSWORD=');
    expectThrows(fn() => RegistrationService::request('dave@example.test', 'Dave', $pass), 'Não foi possível enviar', 'falha de envio');
    putenv('MAIL_MODE=log');
    expect((int) scalar($db, 'SELECT COUNT(*) FROM users WHERE email=?', ['dave@example.test']) === 0, 'cadastro desfeito quando o e-mail falha');

    /* Permissões e envio. */
    $db->exec("INSERT INTO zones (name,active,created_at,updated_at) VALUES ('Zona Teste',1,NOW(3),NOW(3)), ('Zona Inativa',0,NOW(3),NOW(3))");
    $zone = (int) scalar($db, "SELECT id FROM zones WHERE name='Zona Teste'");
    $off = (int) scalar($db, "SELECT id FROM zones WHERE name='Zona Inativa'");
    expect(ManagementController::validatePermission('god', $aliceId, $zone) !== null, 'nível inválido');
    expect(ManagementController::validatePermission('viewer', $adminId, $zone) !== null, 'administrador não recebe vínculo');
    expect(ManagementController::validatePermission('viewer', $bobId, $zone) !== null, 'usuário recusado não recebe vínculo');
    expect(ManagementController::validatePermission('viewer', $aliceId, $off) !== null, 'zona inativa não recebe vínculo');
    expect(ManagementController::validatePermission('viewer', 999999, $zone) !== null, 'usuário inexistente');
    expect(ManagementController::validatePermission('viewer', $aliceId, $zone) === null, 'vínculo válido');
    expect(ZoneController::accessLevel($zone, $aliceId) === null, 'sem vínculo não há acesso');
    $link = $db->prepare('INSERT INTO zone_users (zone_id,user_id,access_level,created_at) VALUES (?,?,?,NOW(3))');
    $link->execute([$zone, $aliceId, 'viewer']);
    expect(ZoneController::accessLevel($zone, $aliceId) === 'viewer' && !ZoneController::canSend('viewer'), 'viewer vê mas não envia');
    $db->prepare("UPDATE zone_users SET access_level='operator' WHERE zone_id=? AND user_id=?")->execute([$zone, $aliceId]);
    expect(ZoneController::canSend(ZoneController::accessLevel($zone, $aliceId)), 'operator envia');
    $link->execute([$off, $aliceId, 'manager']);
    expect(ZoneController::accessLevel($off, $aliceId) === null, 'vínculo com zona inativa não dá acesso');

    /* Limite de tentativas. */
    for ($i = 0; $i < 5; $i++) RateLimiter::hit('teste', 'x');
    expect(RateLimiter::blocked('teste', 'x', 5, 60) === true, 'bloqueia ao atingir o limite');
    expect(RateLimiter::blocked('teste', 'y', 5, 60) === false, 'outro valor não é bloqueado');
    RateLimiter::clear('teste', 'x');
    expect(RateLimiter::blocked('teste', 'x', 5, 60) === false, 'clear libera');

    echo "OK: cadastro, confirmação, login, aprovação/recusa, pré-sequestro, falha de e-mail, permissões, envio e limite de tentativas.\n";
} finally {
    if ($hadLog && $originalLog !== null) file_put_contents($logPath, $originalLog, LOCK_EX);
    elseif (is_file($logPath)) unlink($logPath);
}
