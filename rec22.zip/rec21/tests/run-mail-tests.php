<?php
/**
 * Finalidade: validar configuração e composição de e-mail sem enviar mensagens reais.
 */

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../app/Services/MailService.php';

function expect(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

function setTestEnv(array $values): void
{
    foreach ($values as $key => $value) {
        putenv($key . '=' . $value);
    }
}

$mailerFactory = new class extends MailService {
    public static function buildForTest(array $config): PHPMailer\PHPMailer\PHPMailer
    {
        return parent::createMailer(
            'destinatario@example.test',
            'Assunto de teste',
            '<p>Conteúdo <strong>HTML</strong></p>',
            'Conteúdo texto alternativo',
            $config
        );
    }
};

setTestEnv([
    'APP_ENV' => 'local',
    'MAIL_MODE' => 'log',
    'MAIL_HOST' => 'smtp.gmail.com',
    'MAIL_PORT' => '587',
    'MAIL_ENCRYPTION' => 'tls',
    'MAIL_USERNAME' => 'conta-teste@gmail.com',
    'MAIL_PASSWORD' => 'valor-falso-de-teste',
    'MAIL_FROM_ADDRESS' => 'conta-teste@gmail.com',
    'MAIL_FROM_NAME' => 'Rec Wave Teste',
]);

$config = require __DIR__ . '/../config/mail.php';
expect($config['host'] === 'smtp.gmail.com', 'Host Gmail não carregado.');
expect($config['port'] === 587, 'Porta SMTP incorreta.');
expect($config['encryption'] === 'tls', 'STARTTLS não foi configurado.');
expect($config['mode'] === 'log', 'Modo de teste local não foi carregado.');

$mailer = $mailerFactory::buildForTest($config);
expect($mailer->SMTPAuth, 'Autenticação SMTP não está habilitada.');
expect($mailer->SMTPSecure === PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS, 'PHPMailer não está usando STARTTLS.');
expect($mailer->CharSet === PHPMailer\PHPMailer\PHPMailer::CHARSET_UTF8, 'Codificação UTF-8 não configurada.');
expect($mailer->From === 'conta-teste@gmail.com', 'Remetente configurado incorretamente.');
expect($mailer->getToAddresses()[0][0] === 'destinatario@example.test', 'Destinatário não foi adicionado corretamente.');
expect($mailer->Subject === 'Assunto de teste', 'Assunto não foi definido corretamente.');
expect($mailer->Body === '<p>Conteúdo <strong>HTML</strong></p>', 'Corpo HTML incorreto.');
expect($mailer->AltBody === 'Conteúdo texto alternativo', 'Alternativa em texto simples incorreta.');
expect($mailer->preSend(), 'PHPMailer não conseguiu preparar MIME HTML/texto alternativo.');
expect(str_contains($mailer->getSentMIMEMessage(), 'multipart/alternative'), 'Mensagem MIME não contém partes alternativas.');

$logPath = __DIR__ . '/../storage/logs/mail.log';
$logDirectory = dirname($logPath);
$hadLog = is_file($logPath);
$originalLog = $hadLog ? file_get_contents($logPath) : false;

try {
    expect(
        MailService::send(
            'destinatario@example.test',
            'Teste de log local',
            '<p>HTML exclusivo do teste</p>',
            'Texto alternativo exclusivo do teste'
        ),
        'Modo de log local deveria aceitar a mensagem sem SMTP.'
    );
    $logged = file_get_contents($logPath);
    expect(str_contains($logged, 'Texto alternativo exclusivo do teste'), 'Texto simples não foi registrado no modo local.');
    expect(str_contains($logged, 'HTML exclusivo do teste'), 'HTML não foi registrado no modo local.');
} finally {
    if ($hadLog && $originalLog !== false) {
        file_put_contents($logPath, $originalLog, LOCK_EX);
    } elseif (is_file($logPath)) {
        unlink($logPath);
    }

    if (is_dir($logDirectory) && count(scandir($logDirectory)) === 2) {
        rmdir($logDirectory);
    }
}

setTestEnv(['MAIL_MODE' => 'smtp']);
expect(
    MailService::send('endereco-invalido', 'Teste', '<p>Não enviar</p>') === false,
    'Destinatário inválido deveria ser recusado sem tentar SMTP.'
);
expect(
    MailService::send('destinatario@example.test', "Assunto\nInjetado", '<p>Não enviar</p>') === false,
    'Quebra de linha no assunto deveria ser recusada.'
);

setTestEnv(['APP_ENV' => 'production', 'MAIL_MODE' => 'log']);
expect(
    MailService::send('destinatario@example.test', 'Teste', '<p>Não enviar</p>') === false,
    'Modo de log não pode ser usado fora do ambiente local.'
);

setTestEnv([
    'APP_ENV' => 'local',
    'MAIL_MODE' => 'smtp',
    'MAIL_HOST' => '127.0.0.1',
    'MAIL_PORT' => '1',
    'MAIL_USERNAME' => 'teste-local',
    'MAIL_PASSWORD' => 'senha-falsa',
    'MAIL_FROM_ADDRESS' => 'teste@example.test',
]);
expect(
    MailService::send('destinatario@example.test', 'Teste sem entrega', '<p>Falha local esperada</p>') === false,
    'Falha de conexão SMTP local deveria retornar false.'
);

echo "OK: configuração, STARTTLS, UTF-8, MIME alternativo, log local, validação e falha SMTP. Nenhum e-mail externo enviado.\n";
