<?php
/**
 * Finalidade: verificar conexão e autenticação SMTP sem enviar uma mensagem.
 * Uso: php tests/check-smtp-connection.php
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

$config = require __DIR__ . '/../config/mail.php';

if ($config['mode'] !== 'smtp') {
    fwrite(STDERR, "MAIL_MODE precisa estar como smtp no .env.\n");
    exit(1);
}

if ($config['host'] === '' || $config['username'] === '' || $config['password'] === '') {
    fwrite(STDERR, "Preencha MAIL_HOST, MAIL_USERNAME e MAIL_PASSWORD no .env.\n");
    exit(1);
}

$mailer = new PHPMailer(true);
$mailer->isSMTP();
$mailer->Host = $config['host'];
$mailer->SMTPAuth = true;
$mailer->Username = $config['username'];
$mailer->Password = $config['password'];
$mailer->SMTPSecure = $config['encryption'] === 'ssl'
    ? PHPMailer::ENCRYPTION_SMTPS
    : PHPMailer::ENCRYPTION_STARTTLS;
$mailer->Port = $config['port'];
$mailer->Timeout = 15;
$mailer->SMTPDebug = SMTP::DEBUG_OFF;

try {
    if (!$mailer->smtpConnect()) {
        fwrite(STDERR, "Falha na conexão ou autenticação SMTP. Nenhuma mensagem foi enviada.\n");
        exit(1);
    }

    $mailer->getSMTPInstance()->quit();
    echo "Conexão TLS e autenticação SMTP aceitas. Nenhuma mensagem foi enviada.\n";
} catch (Throwable $error) {
    $message = strtolower($error->getMessage());
    $category = str_contains($message, 'connect')
        ? 'conexão, firewall ou porta'
        : (str_contains($message, 'auth') ? 'usuário ou senha de app' : 'TLS ou configuração SMTP');

    error_log('Rec Wave SMTP check failed (' . get_class($error) . '): ' . $category);
    fwrite(STDERR, "Falha na etapa de {$category}. Confira as configurações e o log PHP. Nenhuma mensagem foi enviada.\n");
    exit(1);
}
