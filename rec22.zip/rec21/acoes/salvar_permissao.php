<?php
/** Finalidade: salvar o nível de acesso de um usuário em uma zona. */
require_once __DIR__.'/../config/config.php';require_once __DIR__.'/../includes/carregar.php';ManagementController::savePermission();
