<?php
/** Finalidade: aprovar uma solicitação enviada pelo painel administrativo. */
require_once __DIR__.'/../config/config.php';require_once __DIR__.'/../includes/carregar.php';AdminController::approve();
