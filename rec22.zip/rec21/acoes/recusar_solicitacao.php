<?php
/** Finalidade: recusar uma solicitação e registrar o motivo informado. */
require_once __DIR__.'/../config/config.php';require_once __DIR__.'/../includes/carregar.php';AdminController::reject();
