<?php
/** Finalidade: receber o formulário de mensagem e registrar uma demonstração na zona. */
require_once __DIR__.'/../config/config.php';require_once __DIR__.'/../includes/carregar.php';ZoneController::send();
