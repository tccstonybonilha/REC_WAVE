<?php
/**
 * Finalidade: carregar o ambiente (.env) para scripts de linha de comando e testes.
 * As páginas web usam includes/carregar.php.
 */
require_once __DIR__ . '/config/config.php';
