<?php /** Finalidade: permitir preferências reais de tema e idioma da interface. */
$pageTitle = 'Configurações';
require __DIR__ . '/../partials/top.php';
$themes = ['dark' => 'Escuro (preto e verde)', 'light' => 'Claro'];
$langs = ['pt-BR' => 'Português', 'en' => 'English']; ?>
		<header class="page-head">
			<h1><?= et('Configurações') ?></h1>
			<p class="page-sub"><?= et('Ajuste a aparência e o idioma da interface.') ?></p>
		</header>
		<form class="card settings-form" method="post" action="<?= Response::url('zonas/configuracoes.php') ?>">
			<input type="hidden" name="_csrf" value="<?= Response::e(Csrf::token()) ?>">
			<fieldset class="settings-group">
				<legend><?= et('Tema') ?></legend>
				<div class="choice-grid">
					<?php foreach ($themes as $value => $label): ?>
						<label class="choice">
							<input type="radio" name="theme" value="<?= $value ?>"<?= $prefs['theme'] === $value ? ' checked' : '' ?>>
							<span class="choice-body">
								<span class="theme-preview" data-theme="<?= $value ?>" aria-hidden="true"><i></i><i></i><i></i></span>
								<span class="choice-title"><?= et($label) ?><span class="choice-check"><?= rw_icon('check', 12) ?></span></span>
							</span>
						</label>
					<?php endforeach; ?>
				</div>
			</fieldset>
			<fieldset class="settings-group">
				<legend><?= et('Idioma') ?></legend>
				<div class="choice-grid">
					<?php foreach ($langs as $value => $label): ?>
						<label class="choice">
							<input type="radio" name="language" value="<?= $value ?>"<?= $prefs['language'] === $value ? ' checked' : '' ?>>
							<span class="choice-body"><span class="choice-title"><?= Response::e($label) ?><span class="choice-check"><?= rw_icon('check', 12) ?></span></span></span>
						</label>
					<?php endforeach; ?>
				</div>
			</fieldset>
			<button class="btn" type="submit"><?= et('Salvar preferências') ?></button>
		</form>
		<p class="note"><?= et('Tema e idioma ficam salvos neste navegador. As telas de login e cadastro, e as mensagens de erro de formulário, permanecem em português.') ?></p>
<?php require __DIR__ . '/../partials/bottom.php'; ?>
