<?php /** Finalidade: fechar a página aberta por partials/top.php. */ ?>
		</div>
	</main>
</div>
<script src="<?= rw_asset('js/app.js') ?>" defer></script>
</body>
</html>
