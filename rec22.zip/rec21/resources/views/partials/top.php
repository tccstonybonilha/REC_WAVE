<?php
/**
 * Finalidade: abrir as telas da área logada (menu lateral, tema, idioma e avisos).
 * Variável esperada: $pageTitle. O menu sai do papel gravado na sessão (revalidado em requireAuth).
 */
$prefs = Preferences::get();
$isAdmin = ($_SESSION['user']['role'] ?? '') === 'admin';
$home = $isAdmin ? 'admin/dashboard.php' : 'zonas/index.php';
$pendentes = $isAdmin ? rw_pending_requests() : 0;
$links = $isAdmin
	? [['admin/dashboard.php', 'Painel', 'grid'], ['admin/solicitacoes.php', 'Solicitações', 'inbox'], ['admin/usuarios.php', 'Usuários', 'users'], ['admin/permissoes.php', 'Permissões', 'key'], ['zonas/configuracoes.php', 'Configurações', 'sliders']]
	: [['zonas/index.php', 'Zonas', 'radio'], ['zonas/configuracoes.php', 'Configurações', 'sliders']];
/* visualizar.php pertence à seção Zonas. */
$atual = str_replace('visualizar.php', 'index.php', basename(dirname($_SERVER['SCRIPT_NAME'] ?? '')) . '/' . basename($_SERVER['SCRIPT_NAME'] ?? ''));
?>
<!doctype html>
<html lang="<?= Response::e($prefs['language']) ?>" data-theme="<?= Response::e($prefs['theme']) ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?= Response::e(t($pageTitle ?? 'Rec Wave')) ?> — Rec Wave</title>
	<link rel="icon" type="image/svg+xml" href="<?= rw_asset('img/favicon.svg') ?>">
	<link rel="stylesheet" href="<?= rw_asset('css/app.css') ?>">
	<script>document.documentElement.classList.add('js')</script>
</head>
<body class="app-body">
<a class="skip-link" href="#conteudo"><?= et('Ir para o conteúdo') ?></a>
<div class="shell">
	<aside class="sidebar">
		<?= rw_brand(Response::url($home)) ?>
		<nav class="side-nav" aria-label="<?= et('Principal') ?>">
			<?php foreach ($links as [$path, $label, $icon]): $ativo = $atual === $path; ?>
				<a class="side-link<?= $ativo ? ' is-active' : '' ?>" href="<?= Response::url($path) ?>"<?= $ativo ? ' aria-current="page"' : '' ?>>
					<?= rw_icon($icon, 18) ?><span><?= et($label) ?></span>
					<?php if ($path === 'admin/solicitacoes.php' && $pendentes > 0): ?><span class="badge" aria-label="<?= (int) $pendentes ?> <?= et('pendentes') ?>"><?= (int) $pendentes ?></span><?php endif; ?>
				</a>
			<?php endforeach; ?>
		</nav>
		<div class="side-user">
			<strong><?= Response::e($_SESSION['user']['name'] ?? '') ?></strong>
			<span><?= et($isAdmin ? 'Administrador' : 'Usuário') ?></span>
			<form method="post" action="<?= Response::url('auth/logout.php') ?>">
				<input type="hidden" name="_csrf" value="<?= Response::e(Csrf::token()) ?>">
				<button class="btn btn-ghost btn-sm btn-block" type="submit"><?= rw_icon('logout', 16) ?><?= et('Sair') ?></button>
			</form>
		</div>
	</aside>
	<main class="shell-main" id="conteudo">
		<div class="page">
		<?= Response::renderFlash() ?>
