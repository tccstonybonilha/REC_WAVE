<?php
/** Finalidade: página inicial. Variáveis: $logado (bool) e $destino (painel do papel atual). */
$tituloPagina = 'Rec Wave — mensagens que atravessam a água';
$classeCorpo = 'page-landing';
require __DIR__ . '/../../../includes/cabecalho.php';

?>
<header class="site-header">
	<?= rw_brand(Response::url('index.php')) ?>
	<nav class="site-nav" aria-label="Principal">
		<a href="#como-funciona">Como funciona</a>
		<a href="#mensagens">Mensagens</a>
		<a href="#acesso">Acesso</a>
		<?php if ($logado): ?>
			<a class="btn btn-ghost btn-sm" href="<?= escapar(Response::url($destino)) ?>">Abrir painel</a>
		<?php else: ?>
			<a class="btn btn-ghost btn-sm" href="<?= escapar(Response::url('auth/login.php')) ?>">Entrar</a>
		<?php endif; ?>
	</nav>
</header>

<main id="conteudo">
	<section class="hero">
		<div class="hero-copy">
			<h1>Mensagens que atravessam a água.</h1>
			<p>O Rec Wave é um sistema de comunicação acústica subaquática. O texto sai da sua tela, passa por um gateway ESP32 e chega a uma unidade submersa por som. Você acompanha cada mensagem do envio à entrega.</p>
			<div class="actions">
				<?php if ($logado): ?>
					<a class="btn" href="<?= escapar(Response::url($destino)) ?>">Abrir painel</a>
				<?php else: ?>
					<a class="btn" href="<?= escapar(Response::url('auth/cadastro.php')) ?>">Solicitar acesso</a>
					<a class="btn btn-ghost" href="<?= escapar(Response::url('auth/login.php')) ?>">Entrar</a>
				<?php endif; ?>
			</div>
		</div>
		<?= rw_waves() ?>
	</section>

	<section class="section" id="como-funciona">
		<div class="section-inner">
			<h2>Do navegador à unidade submersa.</h2>
			<p class="lead">Uma mensagem passa por cinco pontos. Nos quatro primeiros ela viaja por rede comum. O último trecho, o da linha ondulada, é o único que atravessa a água.</p>
			<ol class="route">
				<li><span class="route-node"></span><span class="route-link"></span><strong>Você</strong><span>Escreve a mensagem em uma zona que você tem permissão de usar.</span></li>
				<li><span class="route-node"></span><span class="route-link"></span><strong>Site</strong><span>Confere seu acesso e registra o texto no histórico da zona.</span></li>
				<li><span class="route-node"></span><span class="route-link"></span><strong>Servidor</strong><span>Guarda o estado de cada mensagem e prepara o envio.</span></li>
				<li>
					<span class="route-node"></span>
					<span class="route-link is-wave" aria-hidden="true">
						<svg class="wv-h" viewBox="0 0 200 14" preserveAspectRatio="none"><path d="M0 7q12.5 -7 25 0t25 0t25 0t25 0t25 0t25 0t25 0t25 0"/></svg>
						<svg class="wv-v" viewBox="0 0 14 200" preserveAspectRatio="none"><path d="M7 0q-7 12.5 0 25t0 25t0 25t0 25t0 25t0 25t0 25t0 25"/></svg>
					</span>
					<strong>Gateway ESP32</strong><span>Recebe pela rede e transmite o sinal no meio acústico.</span>
				</li>
				<li><span class="route-node"></span><strong>Unidade subaquática</strong><span>Capta o som e devolve a confirmação de que recebeu.</span></li>
			</ol>
			<p class="aside-note">Wi-Fi e rádio perdem alcance rápido debaixo d’água. Por isso o gateway fica na superfície e a conversa com a unidade acontece por acústica.</p>
		</div>
	</section>

	<section class="section" id="mensagens">
		<div class="section-inner">
			<h2>Cada mensagem mostra onde está.</h2>
			<p class="lead">Nenhuma mensagem aparece como entregue só porque foi enviada. O estado só avança quando o ponto seguinte do caminho confirma.</p>
			<ol class="states">
				<li><?= rw_track('pending', 'Pendente') ?><strong>Pendente</strong><span>Registrada no site e guardada no histórico. Ainda não saiu do servidor.</span></li>
				<li><?= rw_track('sent_to_gateway', 'Enviada ao gateway') ?><strong>Enviada ao gateway</strong><span>O servidor entregou a mensagem ao ESP32 na superfície.</span></li>
				<li><?= rw_track('transmitted_acoustically', 'Transmitida acusticamente') ?><strong>Transmitida acusticamente</strong><span>O gateway emitiu o sinal na água, em direção à unidade.</span></li>
				<li><?= rw_track('delivered', 'Entregue') ?><strong>Entregue</strong><span>A unidade submersa confirmou o recebimento.</span></li>
			</ol>
			<p class="after">Se o envio não completa o caminho, a mensagem passa a <b>Falhou</b> ou <b>Expirada</b>. Nada fica parado sem explicação.</p>
		</div>
	</section>

	<section class="section" id="acesso">
		<div class="section-inner split">
			<div>
				<h2>Acesso por zona, decidido por pessoas.</h2>
				<p class="lead">Quem pede cadastro confirma o e-mail e espera a aprovação de um administrador. Depois, o administrador define o que cada pessoa pode fazer em cada zona. Sem vínculo, a zona nem abre.</p>
			</div>
			<ul class="levels">
				<li><strong>Visualização</strong><span>Lê o histórico de mensagens da zona.</span></li>
				<li><strong>Operação</strong><span>Lê o histórico e envia mensagens.</span></li>
				<li><strong>Gestão</strong><span>Lê e envia; indicado para quem coordena a zona.</span></li>
			</ul>
		</div>
	</section>

	<section class="section" id="etapa">
		<div class="section-inner split">
			<div>
				<h2>O que já funciona hoje.</h2>
				<p class="lead">Esta é a primeira etapa da plataforma. A parte de contas e de histórico está pronta. A ponte física com o equipamento ainda está em construção, e a tela diz isso sem disfarce.</p>
			</div>
			<div class="status-card">
				<h3>Pronto</h3>
				<ul>
					<li><?= rw_icon('check', 18) ?>Cadastro com confirmação por e-mail</li>
					<li><?= rw_icon('check', 18) ?>Aprovação de acesso por administrador</li>
					<li><?= rw_icon('check', 18) ?>Zonas e permissões por pessoa</li>
					<li><?= rw_icon('check', 18) ?>Registro e histórico de mensagens</li>
				</ul>
				<h3>Em construção</h3>
				<ul class="building">
					<li><?= rw_icon('alert', 18) ?>Envio ao gateway ESP32. Até lá, as mensagens ficam em Pendente.</li>
					<li><?= rw_icon('alert', 18) ?>Confirmação de entrega pela unidade submersa.</li>
				</ul>
			</div>
		</div>
	</section>

	<section class="section cta">
		<div class="section-inner">
			<h2>Precisa de acesso a uma zona?</h2>
			<div class="actions">
				<?php if ($logado): ?>
					<a class="btn" href="<?= escapar(Response::url($destino)) ?>">Abrir painel</a>
				<?php else: ?>
					<a class="btn" href="<?= escapar(Response::url('auth/cadastro.php')) ?>">Solicitar cadastro</a>
					<a class="btn btn-ghost" href="<?= escapar(Response::url('auth/login.php')) ?>">Já tenho acesso</a>
				<?php endif; ?>
			</div>
		</div>
	</section>
</main>

<footer class="site-footer">
	<?= rw_brand(Response::url('index.php')) ?>
	<span>Comunicação acústica subaquática</span>
</footer>
<?php require __DIR__ . '/../../../includes/rodape.php'; ?>
