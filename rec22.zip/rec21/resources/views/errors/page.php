<?php
/**
 * Finalidade: tela única de erro. Variáveis: $codigo, $titulo, $texto, $sinal, $inicio, $logado, $voltar, $detail (opcional, só em debug).
 */
require __DIR__ . '/../../../includes/cabecalho.php';
?>
<main class="err" id="conteudo">
	<div class="err-inner">
		<?= rw_brand(Response::url('index.php')) ?>
		<p class="err-code" aria-label="Erro <?= (int) $codigo ?>"><?= (int) $codigo ?></p>
		<h1><?= escapar($titulo) ?></h1>
		<p class="err-text"><?= escapar($texto) ?></p>
		<div class="stack">
			<?php if ($voltar): ?><a class="btn" href="<?= escapar(Response::url($inicio)) ?>" data-action="back" hidden>Voltar e tentar de novo</a><?php endif; ?>
			<a class="btn <?= $voltar ? 'btn-ghost' : '' ?>" href="<?= escapar(Response::url($inicio)) ?>">Voltar ao início</a>
			<?php if (!$logado): ?><a class="btn btn-ghost" href="<?= escapar(Response::url('auth/login.php')) ?>">Entrar</a><?php endif; ?>
		</div>
		<?php if (!empty($detail)): ?><p class="err-debug"><?= escapar($detail) ?></p><?php endif; ?>
		<?= rw_signal($sinal) ?>
	</div>
</main>
<?php require __DIR__ . '/../../../includes/rodape.php'; ?>
