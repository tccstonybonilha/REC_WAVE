<?php /** Finalidade: mostrar zonas disponíveis e indisponíveis sem confundir autorização com conexão física. */
$pageTitle = 'Zonas';
require __DIR__ . '/../partials/top.php'; ?>
		<header class="page-head">
			<h1><?= et('Suas zonas') ?></h1>
			<p class="page-sub"><?= et('Escolha uma zona para abrir a comunicação.') ?></p>
		</header>
		<?php if (!$zones): ?>
			<section class="card empty"><h2><?= et('Nenhuma zona ativa no momento.') ?></h2></section>
		<?php else: ?>
		<div class="zone-grid">
			<?php foreach ($zones as $zone): ?>
				<article class="card zone-card <?= $zone['allowed'] ? 'available' : 'unavailable' ?>">
					<div class="zone-top">
						<?php if ($zone['allowed']): ?>
							<span class="pill success"><?= et('Disponível') ?></span>
							<span class="zone-level"><?= et('Nível') ?>: <?= Response::e(rw_level_label($zone['access_level'])) ?></span>
						<?php else: ?>
							<span class="pill"><?= et('Sem autorização') ?></span>
							<span class="zone-lock"><?= rw_icon('lock', 18) ?></span>
						<?php endif; ?>
					</div>
					<h2><?= Response::e($zone['name']) ?></h2>
					<p class="zone-desc"><?= $zone['description'] ? Response::e($zone['description']) : et('Zona de comunicação subaquática.') ?></p>
					<?php if ($zone['allowed']): ?>
						<?= rw_card_wave() ?>
						<a class="btn zone-action" href="<?= Response::url('zonas/visualizar.php') ?>?id=<?= (int) $zone['id'] ?>"><?= et('Abrir comunicação') ?></a>
					<?php else: ?>
						<p class="zone-ask"><?= et('Peça acesso a um administrador.') ?></p>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>
<?php require __DIR__ . '/../partials/bottom.php'; ?>
