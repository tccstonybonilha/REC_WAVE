<?php /** Finalidade: oferecer chat e histórico por zona, com o estado real de cada mensagem. */
$pageTitle = $zone['name'];
require __DIR__ . '/../partials/top.php';
$me = (int) ($_SESSION['user']['id'] ?? 0);
$canSend = ZoneController::canSend($zone['access_level'] ?? null); ?>
		<a class="back-link" href="<?= Response::url('zonas/index.php') ?>"><?= rw_icon('arrow-left', 16) ?><?= et('Zonas') ?></a>
		<header class="page-head chat-head">
			<div>
				<h1><?= Response::e($zone['name']) ?></h1>
				<?php if (!empty($zone['description'])): ?><p class="page-sub"><?= Response::e($zone['description']) ?></p><?php endif; ?>
			</div>
			<span class="pill success"><?= et('Seu nível') ?>: <?= Response::e(rw_level_label($zone['access_level'] ?? null)) ?></span>
		</header>
		<div class="alert alert-warn"><?= rw_icon('alert', 18) ?><span><?= et('Esta etapa só registra as mensagens. O envio ao gateway ainda não está implementado, então elas permanecem como Pendente.') ?></span></div>
		<section class="card chat" aria-labelledby="chat-title">
			<div class="chat-bar"><h2 id="chat-title"><?= et('Histórico') ?></h2><span><?= et('Gateway não verificado') ?></span></div>
			<ol class="message-list" role="log" tabindex="0" aria-label="<?= et('Histórico de mensagens') ?>" data-scroll-end>
				<?php foreach ($messages as $message):
					$mine = (int) ($message['sender_user_id'] ?? 0) === $me;
					$state = (string) $message['status'];
					$tone = $state === 'failed' ? ' msg-failed' : ($state === 'expired' ? ' msg-expired' : ''); ?>
					<li class="msg<?= $mine ? ' msg-me' : '' ?><?= $tone ?>">
						<div class="msg-head">
							<strong><?= $mine ? et('Você') : Response::e($message['name']) ?></strong>
							<time><?= Response::dt($message['created_at']) ?></time>
							<?php if (!empty($message['is_demo'])): ?><span class="pill pending"><?= et('Teste anterior') ?></span><?php endif; ?>
						</div>
						<p class="msg-text"><?= Response::e($message['content']) ?></p>
						<div class="msg-state"><?= rw_track($state) ?><span><?= Response::e(Response::messageStatus($state)) ?></span></div>
					</li>
				<?php endforeach; ?>
				<?php if (!$messages): ?>
					<li class="chat-empty">
						<strong><?= et('Nenhuma mensagem registrada nesta zona.') ?></strong>
						<p class="muted"><?= et($canSend ? 'Escreva a primeira mensagem abaixo.' : 'Quando alguém registrar mensagens, elas aparecem aqui.') ?></p>
					</li>
				<?php endif; ?>
			</ol>
			<?php if ($canSend): ?>
				<form method="post" action="<?= Response::url('acoes/enviar_mensagem.php') ?>" class="composer" data-composer>
					<input type="hidden" name="_csrf" value="<?= Response::e(Csrf::token()) ?>">
					<input type="hidden" name="zone_id" value="<?= (int) $zone['id'] ?>">
					<label class="sr-only" for="msg-content"><?= et('Mensagem') ?></label>
					<textarea id="msg-content" name="content" rows="1" maxlength="255" placeholder="<?= et('Escreva uma mensagem...') ?>" required></textarea>
					<button class="btn" type="submit"><?= rw_icon('send', 16) ?><?= et('Registrar mensagem') ?></button>
					<span class="counter" data-counter aria-hidden="true">0/255</span>
				</form>
			<?php else: ?>
				<p class="composer-lock"><?= rw_icon('lock', 16) ?><?= et('Seu acesso a esta zona é somente de visualização.') ?></p>
			<?php endif; ?>
		</section>
<?php require __DIR__ . '/../partials/bottom.php'; ?>
