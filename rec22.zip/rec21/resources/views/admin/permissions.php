<?php /** Finalidade: associar usuários comuns a zonas com nível de acesso. */
$pageTitle = 'Permissões';
require __DIR__ . '/../partials/top.php';
$levels = ['viewer' => ['Visualização', 'Lê o histórico de mensagens da zona.'], 'operator' => ['Operação', 'Lê o histórico e envia mensagens.'], 'manager' => ['Gestão', 'Lê e envia; indicado para quem coordena a zona.']]; ?>
		<header class="page-head">
			<h1><?= et('Permissões por zona') ?></h1>
			<p class="page-sub"><?= et('Defina o que cada pessoa pode fazer em cada zona.') ?></p>
		</header>
		<?php if (!$zones): ?>
			<section class="card empty">
				<h2><?= et('Nenhuma zona cadastrada') ?></h2>
				<p class="muted"><?= et('Nenhuma zona cadastrada. Crie uma com: php banco/criar_zona.php "Nome da zona"') ?></p>
			</section>
		<?php elseif (!$users): ?>
			<section class="card empty">
				<h2><?= et('Nenhum usuário aprovado ainda.') ?></h2>
				<p class="muted"><?= et('Aprove uma solicitação para poder conceder acesso a uma zona.') ?></p>
				<a class="btn btn-ghost btn-sm" href="<?= Response::url('admin/solicitacoes.php') ?>"><?= rw_icon('inbox', 16) ?><?= et('Ver solicitações') ?></a>
			</section>
		<?php else: ?>
		<form class="card permission-form" method="post" action="<?= Response::url('acoes/salvar_permissao.php') ?>">
			<input type="hidden" name="_csrf" value="<?= Response::e(Csrf::token()) ?>">
			<div class="perm-fields">
				<div class="field">
					<label for="perm-user"><?= et('Usuário') ?></label>
					<select id="perm-user" name="user_id" required>
						<?php foreach ($users as $u): ?>
							<option value="<?= (int) $u['id'] ?>"><?= Response::e($u['name']) ?> — <?= Response::e($u['email']) ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="field">
					<label for="perm-zone"><?= et('Zona') ?></label>
					<select id="perm-zone" name="zone_id" required>
						<?php foreach ($zones as $z): ?>
							<option value="<?= (int) $z['id'] ?>"><?= Response::e($z['name']) ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
			<fieldset class="settings-group">
				<legend><?= et('Nível') ?></legend>
				<div class="choice-grid three">
					<?php foreach ($levels as $value => [$name, $desc]): ?>
						<label class="choice">
							<input type="radio" name="access_level" value="<?= $value ?>"<?= $value === 'viewer' ? ' checked' : '' ?>>
							<span class="choice-body">
								<span class="choice-title"><?= et($name) ?><span class="choice-check"><?= rw_icon('check', 12) ?></span></span>
								<span class="choice-desc"><?= et($desc) ?></span>
							</span>
						</label>
					<?php endforeach; ?>
				</div>
			</fieldset>
			<button class="btn" type="submit"><?= et('Salvar permissão') ?></button>
		</form>
		<?php endif; ?>
		<p class="note"><?= et('A ausência de vínculo bloqueia a entrada na zona, independentemente do estado do gateway.') ?></p>

		<?php if ($zones): ?>
		<h2 class="section-title"><?= et('Vínculos concedidos') ?></h2>
		<?php if (!$grants): ?>
			<p class="muted"><?= et('Nenhum vínculo concedido ainda.') ?></p>
		<?php else: ?>
		<div class="table-wrap">
			<table class="data-table">
				<thead><tr><th><?= et('Usuário') ?></th><th><?= et('Zona') ?></th><th><?= et('Nível') ?></th></tr></thead>
				<tbody>
				<?php foreach ($grants as $g): ?>
					<tr>
						<td class="cell-who"><div class="who"><strong><?= Response::e($g['name']) ?></strong><span><?= Response::e($g['email']) ?></span></div></td>
						<td data-label="<?= et('Zona') ?>"><?= Response::e($g['zone_name']) ?></td>
						<td data-label="<?= et('Nível') ?>"><span class="pill<?= $g['access_level'] === 'viewer' ? '' : ' success' ?>"><?= Response::e(rw_level_label($g['access_level'])) ?></span></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php endif; endif; ?>
<?php require __DIR__ . '/../partials/bottom.php'; ?>
