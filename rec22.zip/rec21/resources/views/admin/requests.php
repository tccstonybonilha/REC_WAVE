<?php /** Finalidade: permitir aprovação ou recusa de solicitações confirmadas. */
$pageTitle = 'Solicitações';
require __DIR__ . '/../partials/top.php'; ?>
		<header class="page-head">
			<h1><?= et('Solicitações') ?></h1>
			<p class="page-sub"><?= et('Quem confirmou o e-mail espera a sua decisão.') ?></p>
		</header>
		<?php if (!$rows): ?>
			<section class="card empty">
				<h2><?= et('Nenhuma solicitação pendente.') ?></h2>
				<p class="muted"><?= et('Quando alguém confirmar o e-mail, o pedido aparece aqui para você aprovar ou recusar.') ?></p>
			</section>
		<?php else: ?>
		<div class="table-wrap">
			<table class="data-table">
				<thead><tr><th><?= et('Solicitante') ?></th><th><?= et('Pedido em') ?></th><th><?= et('Status') ?></th><th><?= et('Ação') ?></th></tr></thead>
				<tbody>
				<?php foreach ($rows as $row): $id = (int) $row['id']; $pending = $row['account_status'] === 'pending_approval'; ?>
					<tr>
						<td class="cell-who"><div class="who"><strong><?= Response::e($row['name']) ?></strong><span><?= Response::e($row['email']) ?></span></div></td>
						<td class="cell-date" data-label="<?= et('Pedido em') ?>"><?= Response::dt($row['created_at']) ?></td>
						<td class="cell-status" data-label="<?= et('Status') ?>">
							<div>
								<span class="pill <?= $pending ? 'pending' : 'danger' ?>"><?= Response::e(Response::accountStatus($row['account_status'])) ?></span>
								<?php if (!$pending && !empty($row['rejection_reason'])): ?><p class="reason"><?= et('Motivo') ?>: <?= Response::e($row['rejection_reason']) ?></p><?php endif; ?>
							</div>
						</td>
						<td class="cell-actions<?= $pending ? '' : ' is-empty' ?>">
							<?php if ($pending): ?>
							<div class="row-actions" data-reject>
								<form class="approve-form" method="post" action="<?= Response::url('acoes/aprovar_solicitacao.php') ?>">
									<input type="hidden" name="_csrf" value="<?= Response::e(Csrf::token()) ?>">
									<input type="hidden" name="id" value="<?= $id ?>">
									<button class="btn btn-sm" type="submit"><?= rw_icon('check', 16) ?><?= et('Aprovar') ?><span class="sr-only"> — <?= Response::e($row['name']) ?></span></button>
								</form>
								<button class="btn btn-ghost btn-sm reject-toggle" type="button" data-reject-open aria-controls="rj-<?= $id ?>" aria-expanded="false"><?= rw_icon('x', 16) ?><?= et('Recusar') ?><span class="sr-only"> — <?= Response::e($row['name']) ?></span></button>
								<form class="reject-form" id="rj-<?= $id ?>" method="post" action="<?= Response::url('acoes/recusar_solicitacao.php') ?>">
									<input type="hidden" name="_csrf" value="<?= Response::e(Csrf::token()) ?>">
									<input type="hidden" name="id" value="<?= $id ?>">
									<label class="sr-only" for="rs-<?= $id ?>"><?= et('Motivo da recusa') ?></label>
									<input id="rs-<?= $id ?>" name="reason" maxlength="500" placeholder="<?= et('Motivo da recusa') ?>" autocomplete="off" required>
									<button class="btn btn-sm danger-button" type="submit"><?= rw_icon('x', 16) ?><?= et('Confirmar recusa') ?></button>
									<button class="btn btn-ghost btn-sm reject-cancel" type="button" data-reject-cancel><?= et('Cancelar') ?></button>
								</form>
							</div>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php endif; ?>
<?php require __DIR__ . '/../partials/bottom.php'; ?>
