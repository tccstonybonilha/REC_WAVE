<?php /** Finalidade: consultar usuários, papéis e estado de acesso. */
$pageTitle = 'Usuários';
require __DIR__ . '/../partials/top.php';
$tones = ['approved' => 'success', 'pending_approval' => 'pending', 'pending_email' => 'pending']; ?>
		<header class="page-head">
			<h1><?= et('Usuários cadastrados') ?></h1>
			<p class="page-sub"><?= et('Contas cadastradas e o estado de cada uma.') ?></p>
		</header>
		<div class="table-wrap">
			<table class="data-table">
				<thead><tr><th><?= et('Nome') ?></th><th><?= et('Papel') ?></th><th><?= et('Estado') ?></th><th><?= et('Cadastro') ?></th></tr></thead>
				<tbody>
				<?php foreach ($rows as $row): ?>
					<tr>
						<td class="cell-who"><div class="who"><strong><?= Response::e($row['name']) ?></strong><span><?= Response::e($row['email']) ?></span></div></td>
						<td data-label="<?= et('Papel') ?>"><?= et($row['role'] === 'admin' ? 'Administrador' : 'Usuário') ?></td>
						<td data-label="<?= et('Estado') ?>"><span class="pill <?= $tones[$row['account_status']] ?? 'danger' ?>"><?= Response::e(Response::accountStatus($row['account_status'])) ?></span></td>
						<td class="cell-date" data-label="<?= et('Cadastro') ?>"><?= Response::dt($row['created_at']) ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
<?php require __DIR__ . '/../partials/bottom.php'; ?>
