<?php /** Finalidade: apresentar a visão geral administrativa com contagens do banco. */
$pageTitle = 'Administração';
require __DIR__ . '/../partials/top.php';
$pend = (int) $stats['pending']; ?>
		<header class="page-head">
			<h1><?= et('Visão geral') ?></h1>
			<p class="page-sub"><?= et('O que precisa de você agora e o tamanho da plataforma.') ?></p>
		</header>
		<div class="dash">
			<section class="card dash-main<?= $pend > 0 ? ' has-pending' : '' ?>" aria-labelledby="dash-pend">
				<h2 class="card-title" id="dash-pend"><?= et('Solicitações aguardando decisão') ?></h2>
				<p class="big-number"><?= $pend ?></p>
				<?php if ($pend > 0): ?>
					<p><?= Response::e(sprintf(t($pend === 1 ? '%d pessoa confirmou o e-mail e espera sua decisão.' : '%d pessoas confirmaram o e-mail e esperam sua decisão.'), $pend)) ?></p>
					<a class="btn" href="<?= Response::url('admin/solicitacoes.php') ?>"><?= et('Analisar solicitações') ?></a>
				<?php else: ?>
					<p><?= et('Nenhuma solicitação esperando você') ?></p>
				<?php endif; ?>
				<?= rw_card_wave() ?>
			</section>
			<section class="card" aria-labelledby="dash-plat">
				<h2 class="card-title" id="dash-plat"><?= et('Plataforma') ?></h2>
				<dl class="stat-list">
					<?php foreach (['users' => 'Usuários', 'zones' => 'Zonas', 'messages' => 'Mensagens'] as $key => $label): ?>
						<div><dt><?= et($label) ?></dt><dd><?= (int) $stats[$key] ?></dd></div>
					<?php endforeach; ?>
				</dl>
			</section>
			<section class="card dash-wide" aria-labelledby="dash-equip">
				<h2 class="card-title" id="dash-equip"><?= et('Equipamentos') ?></h2>
				<p class="muted"><?= et('Não há comunicação real com gateways nesta etapa. Estados físicos não são inventados nem apresentados como disponíveis.') ?></p>
				<div class="equip-row"><span class="pill pending"><?= et('Status: não verificado') ?></span><span class="dots" aria-hidden="true"></span></div>
			</section>
		</div>
<?php require __DIR__ . '/../partials/bottom.php'; ?>
