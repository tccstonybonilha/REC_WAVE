<?php
/**
 * Finalidade: guardar tema e idioma escolhidos. Valem na sessão e ficam em cookie (sem dados sensíveis),
 * para continuarem depois de sair e também nas telas de login e cadastro.
 */

class Preferences
{
    public const THEMES = ['dark', 'light'];
    public const LANGUAGES = ['pt-BR', 'en'];
    public const DEFAULT_THEME = 'dark';
    public const DEFAULT_LANGUAGE = 'pt-BR';

    /** @return array{theme:string,language:string} */
    public static function get(): array
    {
        $theme = $_SESSION['preferences']['theme'] ?? ($_COOKIE['rw_theme'] ?? null);
        $language = $_SESSION['preferences']['language'] ?? ($_COOKIE['rw_lang'] ?? null);
        return [
            'theme' => is_string($theme) && in_array($theme, self::THEMES, true) ? $theme : self::DEFAULT_THEME,
            'language' => is_string($language) && in_array($language, self::LANGUAGES, true) ? $language : self::DEFAULT_LANGUAGE,
        ];
    }

    /** Valores fora da lista permitida voltam ao padrão. */
    public static function save(mixed $theme, mixed $language): void
    {
        $theme = is_string($theme) && in_array($theme, self::THEMES, true) ? $theme : self::DEFAULT_THEME;
        $language = is_string($language) && in_array($language, self::LANGUAGES, true) ? $language : self::DEFAULT_LANGUAGE;
        $_SESSION['preferences'] = ['theme' => $theme, 'language' => $language];
        if (PHP_SAPI === 'cli' || headers_sent()) return;
        $options = [
            'expires' => time() + 31536000,
            'path' => Response::basePath() ?: '/',
            'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            'httponly' => true,
            'samesite' => 'Lax',
        ];
        setcookie('rw_theme', $theme, $options);
        setcookie('rw_lang', $language, $options);
    }
}
