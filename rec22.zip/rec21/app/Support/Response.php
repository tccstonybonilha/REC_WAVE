<?php
/**
 * Finalidade: padronizar flash messages, redirecionamentos, URLs e escape de saída HTML.
 */

class Response
{
    /**
     * Prefixo da aplicação quando ela não está na raiz do domínio (ex.: /rec21 no XAMPP).
     * 1) APP_BASE_PATH no .env, se definido ("" para raiz), resolve Alias do Apache e links simbólicos;
     * 2) comparação entre o arquivo executado e a raiz do projeto;
     * 3) se as duas falharem, deduz pelo nome da pasta da página (auth, admin, zonas, acoes, erros).
     */
    public static function basePath(): string
    {
        static $base = null;
        if ($base !== null) return $base;
        $override = getenv('APP_BASE_PATH');
        if ($override !== false) {
            $base = self::normalizeBase($override);
            return $base;
        }
        $base = '';
        if (PHP_SAPI !== 'cli') {
            $name = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
            $resolved = false;
            $root = str_replace('\\', '/', (string) realpath(__DIR__ . '/../..'));
            $sf   = $_SERVER['SCRIPT_FILENAME'] ?? '';
            $file = $sf !== '' ? str_replace('\\', '/', (string) realpath($sf)) : '';
            if ($root !== '' && $file !== '' && stripos($file, $root . '/') === 0) {
                $rel = substr($file, strlen($root));            // ex.: /auth/login.php
                if (strlen($name) >= strlen($rel) && strcasecmp(substr($name, -strlen($rel)), $rel) === 0) {
                    $base = substr($name, 0, strlen($name) - strlen($rel));
                    $resolved = true;
                }
            }
            if (!$resolved) {
                if (preg_match('#^(.*?)/(?:auth|admin|zonas|acoes|erros)/[^/]*$#i', $name, $m)) $base = $m[1];
                else $base = str_replace('\\', '/', dirname($name));
            }
        }
        $base = self::normalizeBase($base);
        return $base;
    }

    private static function normalizeBase(string $base): string
    {
        $base = trim(str_replace('\\', '/', $base), '/ ');
        return $base === '' ? '' : '/' . implode('/', array_map('rawurlencode', explode('/', $base)));
    }

    /** Monta a URL de uma página a partir da raiz do projeto (ex.: 'zonas/index.php'). */
    public static function url(string $path = ''): string
    {
        return self::basePath() . '/' . ltrim($path, '/');
    }

    public static function redirect(string $path): never
    {
        header('Location: ' . self::url($path));
        exit;
    }

    public static function flash(string $type, string $message): void
    {
        $_SESSION['_flash'] = ['type' => $type, 'message' => $message];
    }

    public static function consumeFlash(): ?array
    {
        $flash = $_SESSION['_flash'] ?? null;
        unset($_SESSION['_flash']);
        return $flash;
    }

    /** Mostra e consome o aviso pendente, com o estilo certo para sucesso ou erro. */
    public static function renderFlash(): string
    {
        $flash = self::consumeFlash();
        if (!$flash) return '';
        $error = ($flash['type'] ?? '') === 'error';
        return '<div class="alert ' . ($error ? 'alert-error' : 'alert-success') . '" role="' . ($error ? 'alert' : 'status') . '">'
            . rw_icon($error ? 'alert' : 'check', 18) . '<div>' . self::e(t((string) ($flash['message'] ?? ''))) . '</div></div>';
    }

    /** Datas do banco estão sempre em UTC; a tela diz isso. */
    public static function dt(?string $value): string
    {
        return $value ? self::e(substr($value, 0, 19)) . ' UTC' : '';
    }

    public static function accountStatus(string $status): string
    {
        $labels = ['pending_email' => 'E-mail pendente', 'pending_approval' => 'Aguardando aprovação', 'approved' => 'Aprovada', 'rejected' => 'Recusada', 'disabled' => 'Desativada'];
        return t($labels[$status] ?? $status);
    }

    public static function messageStatus(string $status): string
    {
        $labels = ['pending' => 'Pendente', 'sent_to_gateway' => 'Enviada ao gateway', 'transmitted_acoustically' => 'Transmitida acusticamente', 'delivered' => 'Entregue', 'failed' => 'Falhou', 'expired' => 'Expirada'];
        return t($labels[$status] ?? $status);
    }

    public static function e(?string $value): string
    {
        return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
    }
}
