<?php
/**
 * Finalidade: traduzir os textos da interface. O texto-fonte é o próprio português; em inglês, o que
 * não estiver no dicionário continua em português (nunca aparece chave quebrada).
 */

class I18n
{
    private const EN = [
        // navegação
        'Painel' => 'Dashboard', 'Solicitações' => 'Requests', 'Usuários' => 'Users', 'Permissões' => 'Permissions',
        'Configurações' => 'Settings', 'Zonas' => 'Zones', 'Ir para o conteúdo' => 'Skip to content', 'Principal' => 'Main', 'pendentes' => 'pending', 'Administrador' => 'Administrator', 'Sair' => 'Sign out', 'Voltar' => 'Back',
        'Rec Wave / Administração' => 'Rec Wave / Administration',
        // dashboard
        'Administração' => 'Administration', 'Visão geral' => 'Overview',
        'Pendentes' => 'Pending', 'Mensagens' => 'Messages', 'Equipamentos' => 'Equipment',
        'Não há comunicação real com gateways nesta etapa. Estados físicos não são inventados nem apresentados como disponíveis.' => 'There is no real communication with gateways at this stage. Physical states are neither invented nor shown as available.',
        'Status: não verificado' => 'Status: not verified',
        // solicitações / usuários
        'Solicitante' => 'Requester', 'E-mail' => 'E-mail', 'Status' => 'Status', 'Ação' => 'Action',
        'Aprovar' => 'Approve', 'Recusar' => 'Reject', 'Motivo' => 'Reason', 'Nenhuma solicitação pendente.' => 'No pending requests.',
        'Usuários cadastrados' => 'Registered users', 'Nome' => 'Name', 'Papel' => 'Role', 'Estado' => 'State', 'Cadastro' => 'Registered',
        'E-mail pendente' => 'E-mail pending', 'Aguardando aprovação' => 'Awaiting approval', 'Aprovada' => 'Approved', 'Recusada' => 'Rejected', 'Desativada' => 'Disabled',
        // permissões
        'Permissões por zona' => 'Permissions per zone', 'Usuário' => 'User', 'Zona' => 'Zone', 'Nível' => 'Level',
        'Visualização' => 'View only', 'Operação' => 'Operate', 'Gestão' => 'Manage', 'Salvar permissão' => 'Save permission',
        'A ausência de vínculo bloqueia a entrada na zona, independentemente do estado do gateway.' => 'Without a link, access to the zone is blocked, regardless of the gateway state.',
        'Nenhuma zona cadastrada. Crie uma com: php banco/criar_zona.php "Nome da zona"' => 'No zones registered. Create one with: php banco/criar_zona.php "Zone name"',
        // zonas
        'Suas zonas' => 'Your zones', 'Disponível' => 'Available', 'Sem autorização' => 'No access',
        'Zona de comunicação subaquática.' => 'Underwater communication zone.', 'Abrir comunicação' => 'Open communication',
        'Nenhuma zona ativa no momento.' => 'No active zones at the moment.',
        'Gateway não verificado' => 'Gateway not verified',
        'Esta etapa só registra as mensagens. O envio ao gateway ainda não está implementado, então elas permanecem como Pendente.' => 'This stage only records messages. Sending to the gateway is not implemented yet, so they remain Pending.',
        'Nenhuma mensagem registrada nesta zona.' => 'No messages recorded in this zone.', 'estado' => 'state', 'Teste anterior' => 'Earlier test',
        'Escreva uma mensagem...' => 'Write a message...', 'Registrar mensagem' => 'Record message',
        'Seu acesso a esta zona é somente de visualização.' => 'Your access to this zone is view only.',
        'Pendente' => 'Pending', 'Enviada ao gateway' => 'Sent to gateway', 'Transmitida acusticamente' => 'Transmitted acoustically',
        'Entregue' => 'Delivered', 'Falhou' => 'Failed', 'Expirada' => 'Expired',
        // configurações
        'Tema' => 'Theme', 'Idioma' => 'Language', 'Escuro (preto e verde)' => 'Dark (black and green)', 'Claro' => 'Light',
        'Português' => 'Portuguese', 'Salvar preferências' => 'Save preferences',
        'Tema e idioma ficam salvos neste navegador. As telas de login e cadastro, e as mensagens de erro de formulário, permanecem em português.' => 'Theme and language are saved in this browser. Sign-in and sign-up screens, and form error messages, remain in Portuguese.',
        // telas redesenhadas
        'O que precisa de você agora e o tamanho da plataforma.' => 'What needs you now and the size of the platform.',
        'Solicitações aguardando decisão' => 'Requests awaiting a decision',
        '%d pessoa confirmou o e-mail e espera sua decisão.' => '%d person confirmed their e-mail and is waiting for your decision.',
        '%d pessoas confirmaram o e-mail e esperam sua decisão.' => '%d people confirmed their e-mail and are waiting for your decision.',
        'Analisar solicitações' => 'Review requests',
        'Nenhuma solicitação esperando você' => 'No requests waiting for you',
        'Plataforma' => 'Platform',
        'Quem confirmou o e-mail espera a sua decisão.' => 'People who confirmed their e-mail are waiting for your decision.',
        'Pedido em' => 'Requested on',
        'Motivo da recusa' => 'Reason for rejection',
        'Confirmar recusa' => 'Confirm rejection',
        'Cancelar' => 'Cancel',
        'Quando alguém confirmar o e-mail, o pedido aparece aqui para você aprovar ou recusar.' => 'When someone confirms their e-mail, the request appears here for you to approve or reject.',
        'Contas cadastradas e o estado de cada uma.' => 'Registered accounts and the state of each one.',
        'Defina o que cada pessoa pode fazer em cada zona.' => 'Define what each person can do in each zone.',
        'Lê o histórico de mensagens da zona.' => 'Reads the zone\'s message history.',
        'Lê o histórico e envia mensagens.' => 'Reads the history and sends messages.',
        'Lê e envia; indicado para quem coordena a zona.' => 'Reads and sends; meant for whoever coordinates the zone.',
        'Nenhuma zona cadastrada' => 'No zones registered',
        'Nenhum usuário aprovado ainda.' => 'No approved users yet.',
        'Aprove uma solicitação para poder conceder acesso a uma zona.' => 'Approve a request to be able to grant access to a zone.',
        'Ver solicitações' => 'View requests',
        'Vínculos concedidos' => 'Granted links',
        'Nenhum vínculo concedido ainda.' => 'No links granted yet.',
        'Escolha uma zona para abrir a comunicação.' => 'Choose a zone to open its communication.',
        'Peça acesso a um administrador.' => 'Ask an administrator for access.',
        'Seu nível' => 'Your level',
        'Histórico' => 'History',
        'Histórico de mensagens' => 'Message history',
        'Você' => 'You',
        'Mensagem' => 'Message',
        'Escreva a primeira mensagem abaixo.' => 'Write the first message below.',
        'Quando alguém registrar mensagens, elas aparecem aqui.' => 'When someone records messages, they appear here.',
        'Ajuste a aparência e o idioma da interface.' => 'Adjust the look and language of the interface.',
        // avisos
        'Preferências salvas.' => 'Preferences saved.', 'Permissão salva.' => 'Permission saved.', 'Cadastro recusado.' => 'Request rejected.',
        'Cadastro aprovado e comunicado por e-mail.' => 'Request approved and the user was notified by e-mail.',
        'Cadastro aprovado, mas o e-mail não foi enviado; verifique o SMTP.' => 'Request approved, but the e-mail was not sent; check SMTP.',
        'Solicitação não encontrada, já decidida ou e-mail não confirmado.' => 'Request not found, already decided or e-mail not confirmed.',
        'Solicitação não encontrada ou já decidida.' => 'Request not found or already decided.',
        'Nível de acesso inválido.' => 'Invalid access level.', 'Usuário ou zona inválidos.' => 'Invalid user or zone.',
        'Escreva uma mensagem.' => 'Write a message.', 'A mensagem pode ter no máximo 255 caracteres.' => 'The message can have at most 255 characters.',
        'Mensagem registrada como pendente de envio ao gateway.' => 'Message recorded as pending delivery to the gateway.',
    ];

    public static function t(string $text): string
    {
        if (Preferences::get()['language'] !== 'en') return $text;
        return self::EN[$text] ?? $text;
    }
}
