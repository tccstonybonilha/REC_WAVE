<?php
/**
 * Finalidade: limitar tentativas por IP e por e-mail, contando no banco (relógio do MySQL).
 * A tabela rate_limits é criada automaticamente se ainda não existir.
 */

class RateLimiter
{
    private static bool $ready = false;

    public static function ip(): string
    {
        return $_SERVER['REMOTE_ADDR'] ?? 'cli';
    }

    private static function key(string $name, string $value): string
    {
        return hash('sha256', $name . '|' . strtolower($value));
    }

    private static function prepare(): bool
    {
        if (self::$ready) return true;
        try {
            try {
                // Se a tabela já existe (migration 003), não exige permissão de CREATE ao usuário do banco.
                Database::connection()->query('SELECT 1 FROM rate_limits LIMIT 1')->fetchColumn();
                self::$ready = true;
                return true;
            } catch (Throwable $e) {
                // não existe ainda: tenta criar abaixo
            }
            Database::connection()->exec('CREATE TABLE IF NOT EXISTS rate_limits (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                bucket CHAR(64) NOT NULL,
                created_at DATETIME(3) NOT NULL,
                INDEX idx_rate_limits_bucket (bucket, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
            self::$ready = true;
        } catch (Throwable $e) {
            error_log('Rec Wave RateLimiter: ' . $e->getMessage());
        }
        return self::$ready;
    }

    /** true quando o limite de tentativas da janela (em segundos) já foi atingido. */
    public static function blocked(string $name, string $value, int $limit, int $windowSeconds): bool
    {
        if (!self::prepare()) return false;
        try {
            $stmt = Database::connection()->prepare('SELECT COUNT(*) FROM rate_limits WHERE bucket=? AND created_at > NOW(3) - INTERVAL ' . (int) $windowSeconds . ' SECOND');
            $stmt->execute([self::key($name, $value)]);
            return (int) $stmt->fetchColumn() >= $limit;
        } catch (Throwable $e) {
            error_log('Rec Wave RateLimiter: ' . $e->getMessage());
            return false;
        }
    }

    public static function hit(string $name, string $value): void
    {
        if (!self::prepare()) return;
        try {
            $db = Database::connection();
            $db->prepare('INSERT INTO rate_limits (bucket, created_at) VALUES (?, NOW(3))')->execute([self::key($name, $value)]);
            if (random_int(1, 50) === 1) {
                $db->exec('DELETE FROM rate_limits WHERE created_at < NOW(3) - INTERVAL 1 DAY');
            }
        } catch (Throwable $e) {
            error_log('Rec Wave RateLimiter: ' . $e->getMessage());
        }
    }

    public static function clear(string $name, string $value): void
    {
        if (!self::prepare()) return;
        try {
            Database::connection()->prepare('DELETE FROM rate_limits WHERE bucket=?')->execute([self::key($name, $value)]);
        } catch (Throwable $e) {
            error_log('Rec Wave RateLimiter: ' . $e->getMessage());
        }
    }
}
