<?php
/**
 * Finalidade: gerar e validar tokens contra envio forjado de formulários.
 */

class Csrf
{
    public static function token(): string
    {
        return $_SESSION['_csrf'] ??= bin2hex(random_bytes(32));
    }

    public static function validate(mixed $token): void
    {
        if (!is_string($token) || $token === '' || !hash_equals($_SESSION['_csrf'] ?? '', $token)) {
            if (PHP_SAPI === 'cli') { http_response_code(419); exit('Solicitação expirada. Atualize a página e tente novamente.'); }
            ErrorPage::render(419);
        }
    }
}
