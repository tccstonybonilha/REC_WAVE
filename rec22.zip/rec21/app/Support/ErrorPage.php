<?php
/**
 * Finalidade: mostrar as páginas de erro (403, 404, 419, 500) no mesmo visual do restante do site.
 * Não acessa o banco, para funcionar mesmo quando ele estiver fora do ar.
 */
class ErrorPage
{
    private const PAGES = [
        '403' => ['Acesso não autorizado', 'Sua conta não tem permissão para abrir esta página.', 'flat'],
        '403:zona' => ['Zona sem autorização', 'Você não tem vínculo com esta zona. Peça a um administrador para liberar o acesso.', 'flat'],
        '403:admin' => ['Área só para administradores', 'Esta página gerencia contas e permissões. Se você precisa dela, peça a um administrador.', 'flat'],
        '403:visualizacao' => ['Seu nível é só de visualização', 'Você pode ler o histórico desta zona, mas não enviar mensagens. Peça a um administrador o nível Operação.', 'flat'],
        '404' => ['Página não encontrada', 'Esse endereço não existe ou mudou de lugar. Confira o link ou volte ao início.', 'lost'],
        '419' => ['Sua sessão expirou', 'Por segurança, o formulário só vale por um tempo. O que você digitou não foi enviado: volte, atualize a página e tente de novo.', 'fade'],
        '500' => ['Algo falhou do nosso lado', 'Não conseguimos concluir o pedido agora. Tente de novo em instantes; se continuar, avise um administrador.', 'jag'],
    ];

    /** Envia o código HTTP, desenha a página e encerra a execução. */
    public static function render(int $status, string $variant = '', ?string $detail = null): never
    {
        $chave = $variant !== '' && isset(self::PAGES[$status . ':' . $variant]) ? $status . ':' . $variant : (string) $status;
        [$titulo, $texto, $sinal] = self::PAGES[$chave] ?? self::PAGES['500'];
        $codigo = $status;
        if (!headers_sent()) http_response_code($status);

        $logado = !empty($_SESSION['user']['id']);
        $inicio = !$logado ? 'index.php' : (($_SESSION['user']['role'] ?? '') === 'admin' ? 'admin/dashboard.php' : 'zonas/index.php');
        $voltar = in_array($status, [419, 500], true);

        $tituloPagina = $codigo . ' — ' . $titulo . ' — Rec Wave';
        $classeCorpo = 'page-error';
        require __DIR__ . '/../../resources/views/errors/page.php';
        exit;
    }
}
