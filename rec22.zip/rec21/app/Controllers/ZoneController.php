<?php
/** Finalidade: listar zonas, validar autorização e registrar as mensagens de cada zona. */
class ZoneController
{
    public const MAX_MESSAGE_LENGTH = 255;

    private static function userId(): int { AuthenticationService::requireAuth(); return (int) AuthenticationService::user()['id']; }

    /** Só operator e manager enviam; viewer e quem não tem vínculo não. */
    public static function canSend(?string $level): bool { return $level === 'operator' || $level === 'manager'; }

    /** Nível do usuário em uma zona ativa, ou null se não houver vínculo (ou a zona estiver inativa). */
    public static function accessLevel(int $zoneId, int $userId): ?string
    {
        $stmt = Database::connection()->prepare('SELECT zu.access_level FROM zone_users zu JOIN zones z ON z.id=zu.zone_id AND z.active=1 WHERE zu.zone_id=? AND zu.user_id=?');
        $stmt->execute([$zoneId, $userId]); $level = $stmt->fetchColumn();
        return $level === false ? null : (string) $level;
    }

    /** Retorna a mensagem de erro do texto, ou null se estiver válido. */
    public static function validateMessage(string $content): ?string
    {
        $content = trim($content);
        if ($content === '') return 'Escreva uma mensagem.';
        if (mb_strlen($content, 'UTF-8') > self::MAX_MESSAGE_LENGTH) return 'A mensagem pode ter no máximo 255 caracteres.';
        return null;
    }

    public static function index(): void
    {
        $uid = self::userId(); $db = Database::connection();
        $stmt = $db->prepare("SELECT z.id,z.name,z.description,zu.user_id IS NOT NULL AS allowed,zu.access_level FROM zones z LEFT JOIN zone_users zu ON zu.zone_id=z.id AND zu.user_id=? WHERE z.active=1 ORDER BY z.name");
        $stmt->execute([$uid]); $zones = $stmt->fetchAll();
        require __DIR__ . '/../../resources/views/zones/index.php';
    }

    public static function show(): void
    {
        $uid = self::userId(); $id = (int) ($_GET['id'] ?? 0); $db = Database::connection();
        $stmt = $db->prepare('SELECT z.id,z.name,z.description,zu.access_level FROM zones z JOIN zone_users zu ON zu.zone_id=z.id AND zu.user_id=? WHERE z.id=? AND z.active=1');
        $stmt->execute([$uid, $id]); $zone = $stmt->fetch();
        if (!$zone) ErrorPage::render(403, 'zona');
        $m = $db->prepare('SELECT m.content,m.status,m.is_demo,m.created_at,m.sender_user_id,u.name FROM messages m JOIN users u ON u.id=m.sender_user_id WHERE m.zone_id=? ORDER BY m.created_at DESC LIMIT 50');
        $m->execute([$id]); $messages = array_reverse($m->fetchAll());
        require __DIR__ . '/../../resources/views/zones/show.php';
    }

    /** Só envia quem tem nível operator/manager em uma zona ativa; o texto é validado no servidor. */
    public static function send(): void
    {
        $uid = self::userId();
        Csrf::validate($_POST['_csrf'] ?? null);
        $zone = (int) ($_POST['zone_id'] ?? 0);
        $level = self::accessLevel($zone, $uid);
        if ($level === null) ErrorPage::render(403, 'zona');
        if (!self::canSend($level)) ErrorPage::render(403, 'visualizacao');
        $content = is_string($_POST['content'] ?? null) ? trim($_POST['content']) : '';
        $erro = self::validateMessage($content);
        if ($erro !== null) { Response::flash('error', $erro); Response::redirect('zonas/visualizar.php?id=' . $zone); }
        /* A mensagem fica "pending" até existir envio real ao gateway; nada é simulado. */
        $stmt = Database::connection()->prepare("INSERT INTO messages(zone_id,sender_user_id,content,status,created_at) VALUES(?,?,?,'pending',NOW(3))");
        $stmt->execute([$zone, $uid, $content]);
        Response::flash('success', 'Mensagem registrada como pendente de envio ao gateway.');
        Response::redirect('zonas/visualizar.php?id=' . $zone);
    }
}
