<?php
/** Finalidade: concentrar dashboard, usuários, solicitações e permissões administrativas. */
class AdminController
{
    private static function view(string $file, array $data = []): void
    {
        extract($data);
        require __DIR__ . '/../../resources/views/admin/' . $file . '.php';
    }

    public static function dashboard(): void
    {
        AdminMiddleware::requireAdmin();
        $db = Database::connection(); $stats = [];
        foreach (['users', 'zones', 'messages'] as $table) { $stats[$table] = (int) $db->query("SELECT COUNT(*) FROM {$table}")->fetchColumn(); }
        $stats['pending'] = (int) $db->query("SELECT COUNT(*) FROM users WHERE email_verified_at IS NOT NULL AND active=0 AND account_status='pending_approval'")->fetchColumn();
        self::view('dashboard', ['stats' => $stats]);
    }

    public static function requests(): void
    {
        AdminMiddleware::requireAdmin();
        $rows = Database::connection()->query("SELECT id,name,email,created_at,email_verified_at,account_status,rejection_reason FROM users WHERE account_status IN ('pending_approval','rejected') ORDER BY created_at DESC")->fetchAll();
        self::view('requests', ['rows' => $rows]);
    }

    /**
     * Aprova somente solicitações de usuários comuns pendentes de aprovação e com e-mail confirmado.
     * Retorna nome e e-mail do aprovado, ou null quando não há o que aprovar (inexistente, já decidida, desativada, admin).
     */
    public static function approveUser(int $id, int $adminId): ?array
    {
        $db = Database::connection();
        $find = $db->prepare("SELECT name,email FROM users WHERE id=? AND role='user' AND email_verified_at IS NOT NULL AND account_status='pending_approval'");
        $find->execute([$id]); $target = $find->fetch();
        if (!$target) return null;
        $stmt = $db->prepare("UPDATE users SET active=1,account_status='approved',approved_at=NOW(3),approved_by=?,updated_at=NOW(3) WHERE id=? AND role='user' AND email_verified_at IS NOT NULL AND account_status='pending_approval'");
        $stmt->execute([$adminId, $id]);
        return $stmt->rowCount() === 1 ? $target : null;
    }

    /** Recusa somente solicitações pendentes de usuários comuns (nunca administradores nem contas já decididas). */
    public static function rejectUser(int $id, string $reason): bool
    {
        $reason = trim($reason);
        $reason = mb_substr($reason === '' ? 'Não aprovado.' : $reason, 0, 500, 'UTF-8');
        $stmt = Database::connection()->prepare("UPDATE users SET active=0,account_status='rejected',rejection_reason=?,updated_at=NOW(3) WHERE id=? AND account_status='pending_approval' AND role='user'");
        $stmt->execute([$reason, $id]);
        return $stmt->rowCount() === 1;
    }

    public static function approve(): void
    {
        AdminMiddleware::requireAdmin();
        Csrf::validate($_POST['_csrf'] ?? null);
        $target = self::approveUser((int) ($_POST['id'] ?? 0), (int) AuthenticationService::user()['id']);
        if (!$target) { Response::flash('error', 'Solicitação não encontrada, já decidida ou e-mail não confirmado.'); Response::redirect('admin/solicitacoes.php'); }
        $sent = MailService::send($target['email'], 'Acesso aprovado — Rec Wave', '<h2>Seu acesso foi aprovado</h2><p>Olá, ' . htmlspecialchars($target['name'], ENT_QUOTES, 'UTF-8') . '. Você já pode acessar o Rec Wave com a senha definida no cadastro.</p>');
        Response::flash($sent ? 'success' : 'error', $sent ? 'Cadastro aprovado e comunicado por e-mail.' : 'Cadastro aprovado, mas o e-mail não foi enviado; verifique o SMTP.');
        Response::redirect('admin/solicitacoes.php');
    }

    public static function reject(): void
    {
        AdminMiddleware::requireAdmin();
        Csrf::validate($_POST['_csrf'] ?? null);
        $reason = is_string($_POST['reason'] ?? null) ? $_POST['reason'] : '';
        if (!self::rejectUser((int) ($_POST['id'] ?? 0), $reason)) { Response::flash('error', 'Solicitação não encontrada ou já decidida.'); Response::redirect('admin/solicitacoes.php'); }
        Response::flash('success', 'Cadastro recusado.');
        Response::redirect('admin/solicitacoes.php');
    }

    public static function users(): void
    {
        AdminMiddleware::requireAdmin();
        $rows = Database::connection()->query('SELECT id,name,email,role,active,account_status,email_verified_at,created_at FROM users ORDER BY created_at DESC')->fetchAll();
        self::view('users', ['rows' => $rows]);
    }
}
