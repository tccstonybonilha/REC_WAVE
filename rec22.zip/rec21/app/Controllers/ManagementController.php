<?php
/** Finalidade: administrar vínculos de zonas e preferências web do usuário. */
class ManagementController
{
    public static function permissions(): void
    {
        AdminMiddleware::requireAdmin(); $db = Database::connection();
        $users = $db->query("SELECT id,name,email FROM users WHERE role='user' AND active=1 AND account_status='approved' ORDER BY name")->fetchAll();
        $zones = $db->query('SELECT id,name FROM zones WHERE active=1 ORDER BY name')->fetchAll();
        /* Vínculos já concedidos, para o administrador ver o que existe antes de conceder outro. */
        $grantsStmt = $db->prepare('SELECT u.name,u.email,z.name AS zone_name,zu.access_level FROM zone_users zu JOIN users u ON u.id=zu.user_id JOIN zones z ON z.id=zu.zone_id WHERE z.active=1 ORDER BY u.name,z.name');
        $grantsStmt->execute(); $grants = $grantsStmt->fetchAll();
        require __DIR__ . '/../../resources/views/admin/permissions.php';
    }

    /** Valida nível, usuário (comum, ativo e aprovado) e zona (ativa). Retorna a mensagem de erro, ou null se tudo certo. */
    public static function validatePermission(mixed $level, int $userId, int $zoneId): ?string
    {
        if (!is_string($level) || !in_array($level, ['viewer', 'operator', 'manager'], true)) return 'Nível de acesso inválido.';
        $db = Database::connection();
        $user = $db->prepare("SELECT 1 FROM users WHERE id=? AND role='user' AND active=1 AND account_status='approved'"); $user->execute([$userId]);
        $zone = $db->prepare('SELECT 1 FROM zones WHERE id=? AND active=1'); $zone->execute([$zoneId]);
        if (!$user->fetchColumn() || !$zone->fetchColumn()) return 'Usuário ou zona inválidos.';
        return null;
    }

    public static function savePermission(): void
    {
        AdminMiddleware::requireAdmin();
        Csrf::validate($_POST['_csrf'] ?? null);
        $zoneId = (int) ($_POST['zone_id'] ?? 0);
        $userId = (int) ($_POST['user_id'] ?? 0);
        $level = $_POST['access_level'] ?? '';
        $erro = self::validatePermission($level, $userId, $zoneId);
        if ($erro !== null) { Response::flash('error', $erro); Response::redirect('admin/permissoes.php'); }
        $stmt = Database::connection()->prepare('INSERT INTO zone_users(zone_id,user_id,access_level,created_at) VALUES(?,?,?,NOW(3)) ON DUPLICATE KEY UPDATE access_level=VALUES(access_level)');
        $stmt->execute([$zoneId, $userId, $level]);
        Response::flash('success', 'Permissão salva.');
        Response::redirect('admin/permissoes.php');
    }

    public static function settings(): void
    {
        AuthenticationService::requireAuth();
        $prefs = Preferences::get();
        require __DIR__ . '/../../resources/views/settings/index.php';
    }

    public static function saveSettings(): void
    {
        AuthenticationService::requireAuth();
        Csrf::validate($_POST['_csrf'] ?? null);
        Preferences::save($_POST['theme'] ?? null, $_POST['language'] ?? null);
        Response::flash('success', 'Preferências salvas.');
        Response::redirect('zonas/configuracoes.php');
    }
}
