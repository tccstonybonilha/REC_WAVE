<?php
/** Finalidade: garantir no servidor que somente administradores acessem operações administrativas. */
class AdminMiddleware
{
    public static function requireAdmin(): void
    {
        AuthenticationService::requireAuth(); // confere conta ativa/aprovada e atualiza o papel pelo banco
        if (($_SESSION['user']['role'] ?? '') !== 'admin') ErrorPage::render(403, 'admin');
    }
}
