<?php
/**
 * Finalidade: registrar solicitações de acesso, gerar códigos temporários e confirmar e-mails.
 */

class RegistrationService
{
    /**
     * Retorna false (sem erro e sem enviar e-mail) quando o e-mail já tem conta ou pediu código há menos de 60 s,
     * para que a tela não revele quais e-mails existem.
     */
    public static function request(string $email, string $name, string $password): bool
    {
        $email = strtolower(trim($email)); $name = trim($name);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) throw new RuntimeException('Informe um e-mail válido.');
        if (mb_strlen($name, 'UTF-8') < 2 || mb_strlen($name, 'UTF-8') > 120) throw new RuntimeException('Informe seu nome (de 2 a 120 caracteres).');
        if (strlen($password) < 8) throw new RuntimeException('A senha precisa ter pelo menos 8 caracteres.');
        if (strlen($password) > 72) throw new RuntimeException('A senha pode ter no máximo 72 caracteres.');

        $db = Database::connection();
        $code = (string) random_int(100000, 999999);
        $codeHash = password_hash($code, PASSWORD_DEFAULT);
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        $existing = $db->prepare('SELECT id, email_verified_at, (verification_requested_at > NOW(3) - INTERVAL 60 SECOND) AS recent FROM users WHERE email = ?');
        $existing->execute([$email]); $user = $existing->fetch();
        if ($user && $user['email_verified_at']) return false;
        if ($user && (int) $user['recent'] === 1) return false;

        $created = false;
        if ($user) {
            $userId = (int) $user['id'];
            $stmt = $db->prepare("UPDATE users SET name=?, password_hash=?, verification_code_hash=?, verification_expires_at=NOW(3) + INTERVAL 15 MINUTE, verification_attempts=0, verification_requested_at=NOW(3), active=0, account_status='pending_email', updated_at=NOW(3) WHERE id=? AND email_verified_at IS NULL");
            $stmt->execute([$name, $passwordHash, $codeHash, $userId]);
        } else {
            $stmt = $db->prepare("INSERT INTO users (name,email,password_hash,active,role,account_status,verification_code_hash,verification_expires_at,verification_attempts,verification_requested_at,created_at,updated_at) VALUES (?,?,?,0,'user','pending_email',?,NOW(3) + INTERVAL 15 MINUTE,0,NOW(3),NOW(3),NOW(3))");
            $stmt->execute([$name, $email, $passwordHash, $codeHash]);
            $userId = (int) $db->lastInsertId();
            $created = true;
        }
        $html = '<h2>Confirme seu e-mail no Rec Wave</h2><p>Seu código é:</p><p style="font-size:28px;font-weight:bold">'
            . htmlspecialchars($code, ENT_QUOTES, 'UTF-8')
            . '</p><p>Ele expira em 15 minutos e pode ser usado uma única vez.</p>';
        $plainText = "Confirme seu e-mail no Rec Wave\n\nSeu código é: {$code}\n\nEle expira em 15 minutos e pode ser usado uma única vez.";

        if (!MailService::send($email, 'Código de confirmação — Rec Wave', $html, $plainText)) {
            // Não deixa registro "fantasma": remove a conta recém-criada ou libera um novo pedido imediato.
            if ($created) {
                $db->prepare('DELETE FROM users WHERE id=? AND email_verified_at IS NULL')->execute([$userId]);
            } else {
                $db->prepare('UPDATE users SET verification_code_hash=NULL, verification_expires_at=NULL, verification_requested_at=NULL WHERE id=? AND email_verified_at IS NULL')->execute([$userId]);
            }
            throw new RuntimeException('Não foi possível enviar o e-mail agora. Verifique as configurações ou consulte o administrador.');
        }
        return true;
    }

    /**
     * Além do código, exige a senha escolhida no cadastro: quem cadastrou o e-mail de outra pessoa
     * com a própria senha não consegue entregar a conta, e o dono do e-mail não consegue confirmá-la sem saber a senha.
     */
    public static function verify(string $email, string $code, string $password): void
    {
        $db = Database::connection();
        $stmt = $db->prepare('SELECT id, password_hash, verification_code_hash, verification_attempts, email_verified_at, (verification_expires_at < NOW(3)) AS expired FROM users WHERE email=?');
        $stmt->execute([$email]); $user = $stmt->fetch();
        // Uma única mensagem para todo erro de código (inexistente, expirado, esgotado ou errado): não revela quais e-mails têm cadastro pendente.
        $invalido = 'Código inválido ou expirado. Se precisar, solicite um novo código em "Solicitar cadastro".';
        if (!$user || $user['email_verified_at'] || !$user['verification_code_hash'] || (int) $user['expired'] === 1 || (int) $user['verification_attempts'] >= 5) {
            password_hash($code, PASSWORD_DEFAULT); // gasta o mesmo tempo de uma verificação real
            throw new RuntimeException($invalido);
        }
        if (!password_verify($code, $user['verification_code_hash'])) {
            $db->prepare('UPDATE users SET verification_attempts=verification_attempts+1 WHERE id=?')->execute([$user['id']]);
            throw new RuntimeException($invalido);
        }
        if (!password_verify($password, $user['password_hash'])) {
            $db->prepare('UPDATE users SET verification_attempts=verification_attempts+1 WHERE id=?')->execute([$user['id']]);
            throw new RuntimeException('A senha não confere com a informada no cadastro. Se não lembra, solicite o cadastro de novo.');
        }
        $db->prepare("UPDATE users SET email_verified_at=NOW(3), account_status='pending_approval', verification_code_hash=NULL, verification_expires_at=NULL, verification_attempts=0, updated_at=NOW(3) WHERE id=?")->execute([$user['id']]);
    }
}
