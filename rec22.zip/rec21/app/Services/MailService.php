<?php
/**
 * Finalidade: enviar e-mails transacionais por SMTP ou registrar mensagens no modo local.
 */

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

class MailService
{
    public static function send(string $to, string $subject, string $html, string $plainText = ''): bool
    {
        $config = require __DIR__ . '/../../config/mail.php';

        if (!filter_var($to, FILTER_VALIDATE_EMAIL)
            || trim($subject) === ''
            || preg_match('/[\r\n]/', $subject)
            || trim($html) === '') {
            error_log('Rec Wave Mail: destinatário, assunto ou conteúdo inválido.');
            return false;
        }

        if ($config['mode'] === 'log' && $config['app_env'] === 'local') {
            return self::writeLocalLog($to, $subject, $html, $plainText);
        }

        if (!is_file(__DIR__ . '/../../vendor/autoload.php')) {
            error_log('Rec Wave Mail: autoload do Composer não foi encontrado.');
            return false;
        }

        require_once __DIR__ . '/../../vendor/autoload.php';

        if (!class_exists(PHPMailer::class)
            || $config['mode'] !== 'smtp'
            || $config['host'] === ''
            || $config['username'] === ''
            || $config['password'] === ''
            || !filter_var($config['from_address'], FILTER_VALIDATE_EMAIL)
            || !in_array($config['encryption'], ['tls', 'ssl'], true)) {
            error_log('Rec Wave Mail: configuração SMTP ausente ou inválida.');
            return false;
        }

        try {
            $mailer = self::createMailer($to, $subject, $html, $plainText, $config);
            return $mailer->send();
        } catch (Throwable $error) {
            error_log('Rec Wave Mail: falha ao enviar (' . get_class($error) . '): ' . $error->getMessage());
            return false;
        }
    }

    protected static function createMailer(
        string $to,
        string $subject,
        string $html,
        string $plainText,
        array $config
    ): PHPMailer {
        $mailer = new PHPMailer(true);
        $mailer->isSMTP();
        $mailer->Host = $config['host'];
        $mailer->SMTPAuth = true;
        $mailer->Username = $config['username'];
        $mailer->Password = $config['password'];
        $mailer->SMTPSecure = $config['encryption'] === 'ssl'
            ? PHPMailer::ENCRYPTION_SMTPS
            : PHPMailer::ENCRYPTION_STARTTLS;
        $mailer->Port = $config['port'];
        $mailer->Timeout = 15;
        $mailer->SMTPDebug = SMTP::DEBUG_OFF;
        $mailer->CharSet = PHPMailer::CHARSET_UTF8;
        $mailer->Encoding = PHPMailer::ENCODING_BASE64;

        $mailer->setFrom($config['from_address'], $config['from_name']);
        $mailer->addAddress($to);
        $mailer->isHTML(true);
        $mailer->Subject = $subject;
        $mailer->Body = $html;
        $mailer->AltBody = trim($plainText) !== ''
            ? $plainText
            : trim(html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8'));

        return $mailer;
    }

    private static function writeLocalLog(string $to, string $subject, string $html, string $plainText): bool
    {
        $logDirectory = __DIR__ . '/../../storage/logs';
        if (!is_dir($logDirectory) && !mkdir($logDirectory, 0700, true) && !is_dir($logDirectory)) {
            error_log('Rec Wave Mail: não foi possível criar o diretório de logs.');
            return false;
        }

        $body = $plainText !== ''
            ? $plainText
            : trim(html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        $entry = sprintf(
            "[%s] Para: %s\nAssunto: %s\n%s\nHTML:\n%s\n%s\n\n",
            date(DATE_ATOM),
            $to,
            $subject,
            $body,
            $html,
            str_repeat('-', 72)
        );

        if (file_put_contents($logDirectory . '/mail.log', $entry, FILE_APPEND | LOCK_EX) === false) {
            error_log('Rec Wave Mail: não foi possível gravar o e-mail no log local.');
            return false;
        }

        return true;
    }
}
