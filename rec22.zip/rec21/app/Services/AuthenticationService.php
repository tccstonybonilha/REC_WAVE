<?php
/**
 * Finalidade: autenticar contas aprovadas, proteger sessões e encerrar acessos.
 */

/** Credenciais erradas (ou e-mail inexistente): é o único erro de login que conta no limite de tentativas. */
class InvalidCredentialsException extends RuntimeException {}

class AuthenticationService
{
    public static function login(string $email, string $password): void
    {
        $stmt = Database::connection()->prepare('SELECT id,name,email,password_hash,active,role,account_status,email_verified_at FROM users WHERE email=? LIMIT 1');
        $stmt->execute([$email]); $user = $stmt->fetch();
        if ($user) {
            $ok = password_verify($password, $user['password_hash']);
        } else {
            password_hash($password, PASSWORD_DEFAULT); // gasta o mesmo tempo, para não revelar se o e-mail existe
            $ok = false;
        }
        if (!$ok) throw new InvalidCredentialsException('E-mail ou senha inválidos.');
        if (!$user['email_verified_at']) throw new RuntimeException('Confirme seu e-mail antes de entrar.');
        if (!(int)$user['active'] || ($user['account_status'] ?? '') !== 'approved') throw new RuntimeException(($user['account_status'] ?? '') === 'rejected' ? 'Sua solicitação foi recusada.' : 'Sua solicitação aguarda aprovação do administrador.');
        if (session_status() === PHP_SESSION_ACTIVE) session_regenerate_id(true);
        $_SESSION['user'] = ['id'=>$user['id'], 'name'=>$user['name'], 'email'=>$user['email'], 'role'=>$user['role']];
    }

    public static function logout(): void { $_SESSION = []; session_destroy(); }
    public static function user(): ?array { return $_SESSION['user'] ?? null; }

    /** Papel atual da conta no banco, ou null se ela não existe, está inativa ou não está aprovada. */
    public static function activeRole(int $userId): ?string
    {
        $stmt = Database::connection()->prepare('SELECT role,active,account_status FROM users WHERE id=? LIMIT 1');
        $stmt->execute([$userId]); $row = $stmt->fetch();
        if (!$row || !(int) $row['active'] || $row['account_status'] !== 'approved') return null;
        return (string) $row['role'];
    }

    /** Exige sessão e confirma no banco que a conta continua ativa e aprovada (revogação vale na hora). */
    public static function requireAuth(): void
    {
        $session = self::user();
        if (!$session) Response::redirect('auth/login.php');
        $role = self::activeRole((int) $session['id']);
        if ($role === null) {
            unset($_SESSION['user']);
            Response::redirect('auth/login.php');
        }
        $_SESSION['user']['role'] = $role;
    }
}
