<?php
/** Finalidade: página de erro 500 (também serve como ErrorDocument do Apache). */
require_once __DIR__ . '/../includes/security.php';
ErrorPage::render(500);
