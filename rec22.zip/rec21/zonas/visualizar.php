<?php
/** Finalidade: abrir o chat e o histórico da zona autorizada. */
require_once __DIR__.'/../config/config.php';require_once __DIR__.'/../includes/carregar.php';$_GET['id']=$_GET['id']??0;ZoneController::show();
