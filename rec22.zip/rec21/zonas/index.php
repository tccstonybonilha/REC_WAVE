<?php
/** Finalidade: listar as zonas e diferenciar acesso permitido de indisponível. */
require_once __DIR__.'/../config/config.php';require_once __DIR__.'/../includes/carregar.php';ZoneController::index();
