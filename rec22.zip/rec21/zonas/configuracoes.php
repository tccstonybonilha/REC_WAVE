<?php
/** Finalidade: permitir que o usuário salve preferências da interface web. */
require_once __DIR__.'/../config/config.php';require_once __DIR__.'/../includes/carregar.php';if($_SERVER['REQUEST_METHOD']==='POST')ManagementController::saveSettings();else ManagementController::settings();
