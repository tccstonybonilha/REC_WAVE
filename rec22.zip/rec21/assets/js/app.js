/* Rec Wave — melhorias opcionais. Sem JavaScript, todos os formulários continuam funcionando. */
(function () {
	'use strict';

	/* Mostrar/ocultar senha. */
	document.querySelectorAll('[data-toggle-password]').forEach(function (btn) {
		var input = document.getElementById(btn.getAttribute('data-toggle-password'));
		if (!input) return;
		btn.addEventListener('click', function () {
			var show = input.type === 'password';
			input.type = show ? 'text' : 'password';
			btn.classList.toggle('is-on', show);
			btn.setAttribute('aria-pressed', String(show));
			btn.setAttribute('aria-label', show ? 'Ocultar senha' : 'Mostrar senha');
		});
	});

	/* Indicador de força da senha (só orientação visual; a regra real é validada no servidor). */
	document.querySelectorAll('[data-strength]').forEach(function (meter) {
		var input = document.getElementById(meter.getAttribute('data-strength'));
		var status = document.getElementById(meter.getAttribute('data-strength') + '-forca');
		if (!input) return;
		var names = ['', 'Senha fraca', 'Senha razoável', 'Senha boa', 'Senha forte'];
		input.addEventListener('input', function () {
			var v = input.value, level = 0;
			if (v.length) level = 1;
			if (v.length >= 8) level = 2;
			if (v.length >= 10 && /[a-z]/.test(v) && /[A-Z0-9]/.test(v)) level = 3;
			if (v.length >= 12 && /[a-z]/.test(v) && /[A-Z]/.test(v) && /[0-9]/.test(v) && /[^A-Za-z0-9]/.test(v)) level = 4;
			meter.setAttribute('data-level', String(level));
			if (status) status.textContent = names[level];
		});
	});

	/* Código de confirmação: só números. */
	document.querySelectorAll('[data-digits]').forEach(function (input) {
		input.addEventListener('input', function () {
			input.value = input.value.replace(/\D+/g, '').slice(0, 6);
		});
	});

	/* Evita envio duplicado e mostra que o pedido está em andamento. */
	document.querySelectorAll('form[data-loading]').forEach(function (form) {
		var btn = form.querySelector('button[type="submit"], button:not([type])');
		if (!btn) return;
		var original = btn.textContent;
		form.addEventListener('submit', function () {
			if (!form.checkValidity()) return;
			btn.setAttribute('aria-busy', 'true');
			btn.textContent = form.getAttribute('data-loading');
			setTimeout(function () { btn.disabled = true; }, 0);
		});
		window.addEventListener('pageshow', function () {
			btn.disabled = false;
			btn.removeAttribute('aria-busy');
			btn.textContent = original;
		});
	});

	/* Botão "voltar" das páginas de erro. */
	document.querySelectorAll('[data-action="back"]').forEach(function (el) {
		el.hidden = false;
		el.addEventListener('click', function (e) { e.preventDefault(); history.back(); });
	});
	/* Recusar: o campo de motivo abre na própria linha. Sem JavaScript, o campo já aparece direto. */
	document.querySelectorAll('[data-reject]').forEach(function (box) {
		var open = box.querySelector('[data-reject-open]');
		var form = box.querySelector('.reject-form');
		var cancel = box.querySelector('[data-reject-cancel]');
		var input = form && form.querySelector('input[name="reason"]');
		if (!open || !form) return;
		function setOpen(on) {
			box.classList.toggle('is-rejecting', on);
			open.setAttribute('aria-expanded', String(on));
			if (on && input) input.focus(); else if (!on) open.focus();
		}
		open.addEventListener('click', function () { setOpen(true); });
		if (cancel) cancel.addEventListener('click', function () { if (input) input.value = ''; setOpen(false); });
		form.addEventListener('keydown', function (e) {
			if (e.key === 'Escape') { if (input) input.value = ''; setOpen(false); }
		});
	});

	/* Chat: rola até a última mensagem, conta caracteres e envia com Enter (Shift+Enter quebra a linha). */
	document.querySelectorAll('[data-scroll-end]').forEach(function (list) { list.scrollTop = list.scrollHeight; });
	document.querySelectorAll('[data-composer]').forEach(function (form) {
		var box = form.querySelector('textarea');
		var counter = form.querySelector('[data-counter]');
		var btn = form.querySelector('button[type="submit"]');
		if (!box) return;
		var max = parseInt(box.getAttribute('maxlength'), 10) || 255;
		function update() {
			var n = box.value.length;
			if (counter) { counter.textContent = n + '/' + max; counter.classList.toggle('is-near', n >= max - 20); }
			box.style.height = 'auto';
			box.style.height = Math.min(box.scrollHeight, 128) + 'px';
		}
		box.addEventListener('input', update);
		update();
		box.addEventListener('keydown', function (e) {
			if (e.key !== 'Enter' || e.shiftKey || e.isComposing) return;
			e.preventDefault();
			if (box.value.trim() === '') return;
			if (form.requestSubmit) form.requestSubmit(); else form.submit();
		});
		form.addEventListener('submit', function () {
			if (!btn) return;
			setTimeout(function () { btn.disabled = true; }, 0);
		});
		window.addEventListener('pageshow', function () { if (btn) btn.disabled = false; });
	});
})();
