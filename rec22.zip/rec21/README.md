# Rec Wave

## Finalidade

Primeira etapa da plataforma de comunicação subaquática Rec Wave: autenticação, solicitação de cadastro e confirmação de e-mail. A integração real com ESP32 ainda não faz parte desta etapa.

## Estrutura

Cada tela é um arquivo PHP, separado por pasta:

- `auth/`: login, cadastro, confirmação de e-mail e logout;
- `admin/`: dashboard, solicitações, usuários e permissões (todas protegidas por `check_admin.php`);
- `zonas/`: lista de zonas, chat da zona e configurações;
- `acoes/`: processamento dos formulários (aprovar, recusar, salvar permissão, enviar mensagem);
- `includes/`: sessão, segurança (CSRF), cabeçalho, rodapé e carregamento compartilhado;
- `banco/`: esquema SQL, migrations e comandos de linha de comando (`criar_admin.php`, `criar_zona.php`);
- `assets/`: CSS, JavaScript opcional, fontes (Bricolage Grotesque e Figtree, locais) e favicon;
- `erros/`: páginas 403, 404, 419 e 500 (também servem de `ErrorDocument` no Apache);
- `app/`, `config/`, `resources/views/`: serviços, controladores, configurações e telas compartilhadas do painel;
- `storage/logs/`: logs não sensíveis.

Todas as páginas passam por `includes/carregar.php`, que inicia a sessão com um único sistema de CSRF (campo `_csrf`). As pastas internas (`app/`, `config/`, `includes/`, `banco/`, `resources/`, `tests/`, `vendor/`, `storage/`) têm `.htaccess` que bloqueia o acesso direto pelo navegador, e o `.env` também fica bloqueado. Isso exige `AllowOverride All` no Apache.

## Requisitos

- PHP 8.1 ou superior;
- extensões `pdo_mysql`, `openssl` e `mbstring`;
- MySQL/MariaDB compatível com o esquema fornecido;
- PHPMailer (incluído no Composer);
- acesso de saída ao SMTP, quando o envio real estiver habilitado.

## Instalação

1. Copie `.env.example` para `.env`.
2. Preencha o banco no `.env`; nunca publique nem compacte esse arquivo. O envio de e-mail local começa em modo de log.
3. Coloque a pasta em `htdocs` (XAMPP) e acesse `http://localhost/rec21/`, ou rode `php -S localhost:8000` dentro da pasta. As URLs funcionam em qualquer subpasta.
4. Sobre um banco novo, execute `banco/banco_dados.sql` (já inclui tudo; não rode as migrations).
5. Sobre um banco existente, faça backup e execute, **na ordem**, só as migrations cujas colunas ainda não existem:
   - `001_add_authentication_fields.sql`: campos de confirmação de e-mail e `role`;
   - `002_account_status_and_demo.sql`: `account_status`, `approved_at/by`, `rejection_reason` e `is_demo`;
   - `003_rate_limits.sql`: tabela do limite de tentativas (a aplicação também cria sozinha);
   - `004_legacy_users.sql`: libera usuários antigos (ativos viram aprovados; inativos vão para Solicitações). Sem ela, o login e o `criar_admin.php` não funcionam para quem já existia;
   - `005_approved_by_fk.sql`: chave estrangeira de `approved_by` (confira o tipo de `users.id`);
   - `006_message_status_flow.sql`: estados `pending → sent_to_gateway → transmitted_acoustically → delivered`.
6. Confirme que o servidor PHP possui permissão de escrita apenas em `storage/logs/`.
7. Zonas são reais e cadastradas por você, sem dados fictícios: `php banco/criar_zona.php "Nome da zona" "Descrição opcional"`.
8. Se os links quebrarem (Alias do Apache ou link simbólico), defina `APP_BASE_PATH` no `.env` com a pasta da URL (ex.: `/rec21`).

Para desenvolvimento local (o `router.php` mostra a página 404 do Rec Wave e bloqueia as pastas internas):

```bash
php -S localhost:8000 router.php
```

No Apache, para usar as páginas de erro do Rec Wave, descomente as linhas `ErrorDocument` do `.htaccess` ajustando o prefixo da pasta.

## E-mail de confirmação

O cadastro já envia um código de confirmação pelo `RegistrationService`. A aplicação usa PHPMailer, remetente configurado pelo servidor e uma alternativa em texto simples. Não há recuperação de senha implementada neste projeto.

### Configurar Gmail SMTP

1. Na Conta Google remetente, ative a verificação em duas etapas.
2. Crie uma senha de app nas configurações de segurança da Conta Google. O Google pode não oferecer essa opção em contas de trabalho/escola, contas com Proteção Avançada ou outras contas gerenciadas.
3. Copie `.env.example` para `.env` se ainda não existir. Mantenha `.env` fora do Git e preencha:

```dotenv
APP_ENV=local
MAIL_MODE=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_ENCRYPTION=tls
MAIL_USERNAME=seu-endereco@gmail.com
MAIL_PASSWORD=sua-senha-de-aplicativo
MAIL_FROM_ADDRESS=seu-endereco@gmail.com
MAIL_FROM_NAME="Rec Wave"
```

Use a senha de app, nunca a senha normal da Conta Google. `MAIL_FROM_ADDRESS` deve ser a mesma conta autenticada ou um alias autorizado no Gmail. Não compartilhe nem versione credenciais.

Com `MAIL_MODE=log` e `APP_ENV=local`, nenhum e-mail é enviado: a mensagem de desenvolvimento é gravada em `storage/logs/mail.log` para permitir confirmar o cadastro sem SMTP. Para enviar de verdade, informe as credenciais e altere `MAIL_MODE=smtp`. O código de confirmação expira em 15 minutos; há intervalo mínimo de 60 segundos entre solicitações do mesmo cadastro não confirmado.

### Testar e diagnosticar

Execute os testes automatizados, que não enviam e-mail externo:

```bash
php tests/run-mail-tests.php
php tests/run-unit-tests.php
```

`run-unit-tests.php` não usa banco (leitor do `.env`, preferências, tradução, validações e regras de acesso). `tests/run-db-tests.php` cobre cadastro, confirmação, login, aprovação, permissões e limite de tentativas, mas **apaga e recria as tabelas**: ele só roda com `TEST_DB_DATABASE=<banco de testes>` (o nome precisa conter `test` e ser diferente de `DB_DATABASE`):

```bash
TEST_DB_DATABASE=rec_wave_test php tests/run-db-tests.php
```

Para testar entrega real, configure as credenciais acima, use `MAIL_MODE=smtp`, inicie a aplicação e solicite cadastro com um endereço de e-mail que você controla. Confira a caixa de entrada e spam; o sucesso SMTP indica aceitação pelo servidor, não garante entrega final. Não execute esse teste durante testes automatizados.

- Erro de autenticação: confirme a verificação em duas etapas, a senha de app e se o usuário é o endereço Gmail completo. Não use a senha normal.
- Erro de conexão/timeout: confira acesso à internet, extensão PHP `openssl`, firewall/antivírus e liberação de saída TCP na porta 587.
- Remetente recusado: alinhe `MAIL_FROM_ADDRESS` com a conta autenticada ou com um alias autorizado.
- Falhas técnicas são gravadas no log PHP do servidor; a resposta ao usuário não expõe detalhes SMTP ou credenciais.

## Fluxo de teste

1. Acesse `auth/cadastro.php`.
2. Solicite cadastro com um e-mail controlado; com modo `log`, leia o código em `storage/logs/mail.log`, ou com SMTP configurado confira o e-mail.
3. Informe o código recebido em `auth/verificar_email.php`, junto com a senha escolhida no cadastro.
4. O sistema exibirá que a solicitação aguarda aprovação; confirmação não ativa a conta.
5. Depois de confirmar o e-mail, promova o primeiro administrador com:

```bash
php banco/criar_admin.php email@dominio.com
```

O comando exige que o e-mail já esteja confirmado e não contém credenciais padrão. A coluna `role` precisa existir no banco de produção; adicione-a por migration revisada se o esquema existente ainda não possuir papéis.

6. Faça login em `auth/login.php`. Administradores vão para `admin/dashboard.php`; usuários aprovados vão para `zonas/index.php`.

## Páginas principais

- `admin/dashboard.php`, `admin/solicitacoes.php`, `admin/usuarios.php`, `admin/permissoes.php`: painel administrativo;
- `zonas/index.php`: zonas do usuário autenticado;
- `zonas/visualizar.php?id=1`: comunicação da zona autorizada; as mensagens ficam como `pending` até existir envio real ao gateway;
- `zonas/configuracoes.php`: tema (escuro preto e verde, ou claro) e idioma (português ou inglês) das telas logadas, salvos no navegador.

## Segurança

Tentativas de login, cadastro e confirmação de e-mail são limitadas por IP e por e-mail (tabela `rate_limits`, criada automaticamente; também em `banco/migrations/003_rate_limits.sql`). A tela de cadastro não revela se um e-mail já existe. A confirmação de e-mail exige o código e a senha escolhida no cadastro. Datas ficam em UTC (PHP e MySQL) e aparecem com o sufixo UTC. Só credenciais erradas contam no limite de login. Erros técnicos vão para o log do PHP; a tela só mostra o erro detalhado com `APP_DEBUG=true` (somente desenvolvimento).

Consultas utilizam PDO com prepared statements, senhas usam `password_hash`, formulários usam CSRF, sessões são regeneradas no login e as saídas HTML são escapadas. O envio de e-mail só é considerado bem-sucedido quando o SMTP confirma a entrega ao servidor.

## Estado da implementação

Nada é simulado: não há zonas nem mensagens de demonstração, e nenhum estado físico é inventado. O envio ao gateway/ESP32 ainda não existe, então as mensagens ficam `pending`. A tabela `message_deliveries` está reservada para essa etapa.

## Interface

Identidade preto e verde com ondas como motivo. Componentes visuais ficam em `includes/ui.php` (ícones, logo, ondas, trilha de estado da mensagem, etapas, sinal pontilhado dos erros) e o estilo em `assets/css/app.css`. As telas públicas são sempre escuras; a área logada respeita o tema escolhido em Configurações.

Redesenhadas: página inicial, entrada, cadastro, confirmação de e-mail, solicitação recebida e erros 403/404/419/500. O menu lateral da área logada já está pronto; as telas internas (painel, solicitações, usuários, permissões, zonas, chat e configurações) ainda usam o estilo provisório e serão redesenhadas na próxima etapa.
