<?php
/**
 * Rec Wave/auth/login.php
 * Finalidade: autenticar o usuário e encaminhá-lo conforme seu papel.
 */
require_once __DIR__ . '/../includes/carregar.php';

function destinoPorPapel(): string
{
	return ($_SESSION['user']['role'] ?? '') === 'admin' ? '../admin/dashboard.php' : '../zonas/index.php';
}

if (!empty($_SESSION['user']['id'])) {
	header('Location: ' . destinoPorPapel());
	exit;
}

$mensagem = '';
$tomMensagem = 'error';
$precisaConfirmar = false;
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	verificarCsrf();
	$email = strtolower(trim(is_string($_POST['email'] ?? null) ? $_POST['email'] : ''));
	$senha = is_string($_POST['senha'] ?? null) ? $_POST['senha'] : '';
	$ip = RateLimiter::ip();

	if (RateLimiter::blocked('login-ip', $ip, 20, 900) || RateLimiter::blocked('login-email', $email, 5, 900)) {
		$mensagem = 'Muitas tentativas. Aguarde alguns minutos.';
		$tomMensagem = 'warn';
	} else {
		try {
			AuthenticationService::login($email, $senha);
			RateLimiter::clear('login-email', $email);
			header('Location: ' . destinoPorPapel());
			exit;
		} catch (Throwable $erro) {
			/* Só credenciais erradas contam no limite; quem acertou a senha e aguarda aprovação não é bloqueado. */
			if ($erro instanceof InvalidCredentialsException) {
				RateLimiter::hit('login-ip', $ip);
				RateLimiter::hit('login-email', $email);
			}
			$mensagem = mensagemSegura($erro);
			/* Credencial errada é erro; o resto (aguardando aprovação, e-mail por confirmar) é um aviso. */
			$tomMensagem = $erro instanceof InvalidCredentialsException ? 'error' : 'warn';
			$precisaConfirmar = $mensagem === 'Confirme seu e-mail antes de entrar.';
		}
	}
}

$tituloPagina = 'Entrar — Rec Wave';
$classeCorpo = 'page-auth';

require __DIR__ . '/../includes/cabecalho.php';
?>
<div class="auth">
	<aside class="auth-art">
		<?= rw_brand(Response::url('index.php')) ?>
		<?= rw_waves() ?>
		<div class="auth-copy">
			<h2>Da sua tela até o fundo da água.</h2>
			<p>Acesso por zona, liberado por um administrador. Cada mensagem mostra em que ponto do caminho está.</p>
		</div>
	</aside>
	<main class="auth-panel" id="conteudo">
		<div class="auth-card">
			<h1>Entrar</h1>
			<p class="lead">Use o e-mail e a senha do seu cadastro.</p>

			<?php if ($mensagem): ?>
				<div class="alert alert-<?= $tomMensagem ?>" role="alert">
					<?= rw_icon('alert', 18) ?>
					<div>
						<?= escapar($mensagem) ?>
						<?php if ($precisaConfirmar): ?> <a href="verificar_email.php?email=<?= urlencode($email) ?>">Confirmar e-mail</a><?php endif; ?>
					</div>
				</div>
			<?php endif; ?>

			<form method="post" data-loading="Entrando…">
				<?= campoCsrf() ?>
				<div class="field">
					<label for="email">E-mail</label>
					<input id="email" type="email" name="email" value="<?= escapar($email) ?>" autocomplete="email" autocapitalize="none" spellcheck="false" required autofocus>
				</div>
				<div class="field">
					<label for="senha">Senha</label>
					<div class="input-wrap">
						<input id="senha" type="password" name="senha" autocomplete="current-password" required>
						<button class="reveal" type="button" data-toggle-password="senha" aria-label="Mostrar senha" aria-pressed="false"><span class="i-on"><?= rw_icon('eye') ?></span><span class="i-off"><?= rw_icon('eye-off') ?></span></button>
					</div>
				</div>
				<button class="btn btn-block" type="submit">Entrar</button>
			</form>

			<p class="form-foot">Ainda não tem acesso? <a href="cadastro.php">Solicitar cadastro</a></p>
		</div>
	</main>
</div>
<?php require __DIR__ . '/../includes/rodape.php'; ?>
