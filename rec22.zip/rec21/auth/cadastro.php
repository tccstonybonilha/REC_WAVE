<?php
/** Finalidade: receber a solicitação de cadastro e enviar o código de confirmação. */
require_once __DIR__ . '/../includes/carregar.php';

$mensagem = '';
$nome = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	verificarCsrf();
	$email = strtolower(trim(is_string($_POST['email'] ?? null) ? $_POST['email'] : ''));
	$nome  = trim(is_string($_POST['nome'] ?? null) ? $_POST['nome'] : '');
	$senha = is_string($_POST['senha'] ?? null) ? $_POST['senha'] : '';
	$ip = RateLimiter::ip();

	try {
		if (RateLimiter::blocked('cadastro-ip', $ip, 30, 3600) || RateLimiter::blocked('cadastro-email', $email, 5, 3600)) {
			throw new RuntimeException('Muitas solicitações. Aguarde um pouco antes de tentar novamente.');
		}
		RateLimiter::hit('cadastro-ip', $ip);
		RateLimiter::hit('cadastro-email', $email);
		RegistrationService::request($email, $nome, $senha);
		header('Location: verificar_email.php?email=' . urlencode($email));
		exit;
	} catch (Throwable $erro) {
		$mensagem = mensagemSegura($erro);
	}
}

$tituloPagina = 'Solicitar cadastro — Rec Wave';
$classeCorpo = 'page-auth';

require __DIR__ . '/../includes/cabecalho.php';
?>
<div class="auth">
	<aside class="auth-art">
		<?= rw_brand(Response::url('index.php')) ?>
		<?= rw_waves() ?>
		<div class="auth-copy">
			<h2>Da sua tela até o fundo da água.</h2>
			<p>Acesso por zona, liberado por um administrador. Cada mensagem mostra em que ponto do caminho está.</p>
		</div>
	</aside>
	<main class="auth-panel" id="conteudo">
		<div class="auth-card">
			<?= rw_stepper(0) ?>
			<h1>Solicitar cadastro</h1>
			<p class="lead">Enviaremos um código para o seu e-mail. Depois, um administrador libera o acesso às zonas.</p>

			<?php if ($mensagem): ?>
				<div class="alert alert-error" role="alert"><?= rw_icon('alert', 18) ?><div><?= escapar($mensagem) ?></div></div>
			<?php endif; ?>

			<form method="post" data-loading="Enviando código…">
				<?= campoCsrf() ?>
				<div class="field">
					<label for="nome">Nome</label>
					<input id="nome" name="nome" value="<?= escapar($nome) ?>" maxlength="120" autocomplete="name" required autofocus>
				</div>
				<div class="field">
					<label for="email">E-mail</label>
					<input id="email" type="email" name="email" value="<?= escapar($email) ?>" maxlength="190" autocomplete="email" autocapitalize="none" spellcheck="false" required>
				</div>
				<div class="field">
					<label for="senha">Senha</label>
					<div class="input-wrap">
						<input id="senha" type="password" name="senha" minlength="8" maxlength="72" autocomplete="new-password" aria-describedby="senha-dica" required>
						<button class="reveal" type="button" data-toggle-password="senha" aria-label="Mostrar senha" aria-pressed="false"><span class="i-on"><?= rw_icon('eye') ?></span><span class="i-off"><?= rw_icon('eye-off') ?></span></button>
					</div>
					<div class="meter" data-strength="senha" data-level="0"><i></i><i></i><i></i><i></i></div>
					<span class="sr-only" id="senha-forca" aria-live="polite"></span>
					<p class="hint" id="senha-dica">De 8 a 72 caracteres. Você vai digitar esta senha de novo ao confirmar o e-mail.</p>
				</div>
				<button class="btn btn-block" type="submit">Enviar código de confirmação</button>
			</form>

			<p class="form-foot">Já tem acesso? <a href="login.php">Entrar</a></p>
		</div>
	</main>
</div>
<?php require __DIR__ . '/../includes/rodape.php'; ?>
