<?php
/** Finalidade: validar o código de confirmação enviado ao e-mail (e a senha escolhida no cadastro). */
require_once __DIR__ . '/../includes/carregar.php';

$mensagem = '';
$confirmado = false;
$emailForm = is_string($_GET['email'] ?? null) ? trim($_GET['email']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	verificarCsrf();
	$email  = strtolower(trim(is_string($_POST['email'] ?? null) ? $_POST['email'] : ''));
	$codigo = trim(is_string($_POST['codigo'] ?? null) ? $_POST['codigo'] : '');
	$senha  = is_string($_POST['senha'] ?? null) ? $_POST['senha'] : '';
	$emailForm = $email;
	$ip = RateLimiter::ip();

	try {
		if (RateLimiter::blocked('verificar-ip', $ip, 30, 900) || RateLimiter::blocked('verificar-email', $email, 10, 900)) {
			throw new RuntimeException('Muitas tentativas. Aguarde alguns minutos.');
		}
		RegistrationService::verify($email, $codigo, $senha);
		$confirmado = true;
	} catch (Throwable $erro) {
		RateLimiter::hit('verificar-ip', $ip);
		RateLimiter::hit('verificar-email', $email);
		$mensagem = mensagemSegura($erro);
	}
}

$tituloPagina = ($confirmado ? 'Solicitação recebida' : 'Confirmar e-mail') . ' — Rec Wave';
$classeCorpo = 'page-auth';

require __DIR__ . '/../includes/cabecalho.php';
?>
<div class="auth">
	<aside class="auth-art">
		<?= rw_brand(Response::url('index.php')) ?>
		<?= rw_waves() ?>
		<div class="auth-copy">
			<h2>Da sua tela até o fundo da água.</h2>
			<p>Acesso por zona, liberado por um administrador. Cada mensagem mostra em que ponto do caminho está.</p>
		</div>
	</aside>
	<main class="auth-panel" id="conteudo">
		<div class="auth-card">
		<?php if ($confirmado): ?>
			<?= rw_stepper(2) ?>
			<div class="seal"><?= rw_icon('clock', 26) ?></div>
			<h1>Solicitação recebida</h1>
			<p class="lead">Seu e-mail foi confirmado. Agora um administrador precisa liberar o seu acesso; você recebe um e-mail quando isso acontecer.</p>
			<ul class="checklist">
				<li><?= rw_icon('check', 18) ?> E-mail confirmado</li>
				<li class="waiting"><?= rw_icon('clock', 18) ?> Aguardando aprovação do administrador</li>
			</ul>
			<div class="stack">
				<a class="btn" href="login.php">Ir para o login</a>
				<a class="btn btn-ghost" href="../index.php">Página inicial</a>
			</div>
		<?php else: ?>
			<?= rw_stepper(1) ?>
			<h1>Confirmar e-mail</h1>
			<p class="lead">Se o e-mail informado puder receber um cadastro, enviamos um código de seis dígitos. Confira também a caixa de spam. O código vale por 15 minutos.</p>

			<?php if ($mensagem): ?>
				<div class="alert alert-error" role="alert"><?= rw_icon('alert', 18) ?><div><?= escapar($mensagem) ?></div></div>
			<?php endif; ?>

			<form method="post" data-loading="Confirmando…">
				<?= campoCsrf() ?>
				<div class="field">
					<label for="email">E-mail</label>
					<input id="email" type="email" name="email" value="<?= escapar($emailForm) ?>" autocomplete="email" autocapitalize="none" spellcheck="false" required>
				</div>
				<div class="field">
					<label for="codigo">Código de seis dígitos</label>
					<input id="codigo" class="code-input" name="codigo" maxlength="6" inputmode="numeric" pattern="[0-9]{6}" autocomplete="one-time-code" placeholder="······" data-digits required<?= $emailForm !== '' ? ' autofocus' : '' ?>>
				</div>
				<div class="field">
					<label for="senha">Senha escolhida no cadastro</label>
					<div class="input-wrap">
						<input id="senha" type="password" name="senha" autocomplete="current-password" aria-describedby="senha-dica" required>
						<button class="reveal" type="button" data-toggle-password="senha" aria-label="Mostrar senha" aria-pressed="false"><span class="i-on"><?= rw_icon('eye') ?></span><span class="i-off"><?= rw_icon('eye-off') ?></span></button>
					</div>
					<p class="hint" id="senha-dica">Se pediu o código mais de uma vez, use o mais recente e a senha da primeira vez que digitou.</p>
				</div>
				<button class="btn btn-block" type="submit">Confirmar e-mail</button>
			</form>

			<p class="form-foot">Errou o e-mail? <a href="cadastro.php">Voltar ao cadastro</a></p>
		<?php endif; ?>
		</div>
	</main>
</div>
<?php require __DIR__ . '/../includes/rodape.php'; ?>
