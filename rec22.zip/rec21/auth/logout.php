<?php
/** Finalidade: encerrar a sessão (somente por POST com CSRF) e retornar ao login. */
require_once __DIR__ . '/../includes/carregar.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	verificarCsrf();
	$_SESSION = [];
	if (ini_get('session.use_cookies')) {
		$p = session_get_cookie_params();
		setcookie(session_name(), '', ['expires' => time() - 42000, 'path' => $p['path'], 'domain' => $p['domain'], 'secure' => $p['secure'], 'httponly' => $p['httponly'], 'samesite' => $p['samesite'] ?? 'Lax']);
	}
	session_destroy();
}
header('Location: login.php');
exit;
