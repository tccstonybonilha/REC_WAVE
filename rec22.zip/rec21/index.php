<?php
/** Finalidade: página inicial pública do Rec Wave (quem já está logado vê o atalho para o painel). */
require_once __DIR__ . '/includes/carregar.php';

$logado = !empty($_SESSION['user']['id']);
$destino = ($_SESSION['user']['role'] ?? '') === 'admin' ? 'admin/dashboard.php' : 'zonas/index.php';

require __DIR__ . '/resources/views/public/landing.php';
